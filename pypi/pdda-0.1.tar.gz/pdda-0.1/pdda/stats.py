from __future__ import annotations

import typing

import numpy as np

if typing.TYPE_CHECKING:
    from typing import Union

    from numpy.typing import NDArray


def prevpow2(x: Union[int, float]) -> int:
    """
    Calculate the largest power of 2 smaller than or equal to the absolute value
    of the given input.

    :param x: The input number.
    :return: The largest power of 2 <= abs(x). Returns 1 if abs(x) < 1.
    """
    n = int(abs(x))
    return 1 if n == 0 else 1 << (n.bit_length() - 1)


def sem_corr(x: NDArray[np.float64]) -> np.float64:
    """
    Compute the standard error of the mean (SEM) of correlated data.

    Uses the automated blocking method proposed by Jonsson
    (https://doi.org/10.1103/PhysRevE.98.043304). This is an adaptation of their code.

    :param x: 1D array of samples (correlated time series).
    :return: Estimated SEM of the sample mean.
    :raises ValueError: If there is insufficient data for a reliable SEM estimate.
    """
    if x.ndim != 1:
        raise ValueError("sem_corr expects a 1D array")
    if x.size < 4:
        raise ValueError("need at least 4 samples for SEM estimation")

    if not np.all(np.isfinite(x)):
        raise ValueError("x contains non-finite values")

    # Truncate the data to a power of 2.
    n = prevpow2(x.size)
    if n < 4:
        raise ValueError("need more data for SEM estimation")

    d = int(np.log2(n))
    x = np.asarray(x[:n], dtype=np.float64)

    # Magic numbers (chi-square quantiles) from Jonsson's paper.
    q = np.array(
        [
            6.634897,
            9.210340,
            11.344867,
            13.276704,
            15.086272,
            16.811894,
            18.475307,
            20.090235,
            21.665994,
            23.209251,
            24.724970,
            26.216967,
            27.688250,
            29.141238,
            30.577914,
            31.999927,
            33.408664,
            34.805306,
            36.190869,
            37.566235,
            38.932173,
            40.289360,
            41.638398,
            42.979820,
            44.314105,
            45.641683,
            46.962942,
            48.278236,
            49.587884,
            50.892181,
        ],
        dtype=np.float64,
    )

    if d >= q.size:
        raise ValueError("need more data for SEM estimation")

    s = np.zeros(d, dtype=np.float64)
    gamma = np.zeros(d, dtype=np.float64)

    # The blocking transform preserves the mean (up to rounding), so compute mu once.
    mu = np.mean(x)

    # Blocking loop.
    for i in range(d):
        s[i] = np.var(x)  # ddof=0
        if s[i] == 0.0:
            # Constant series: the mean is exact, so SEM is zero.
            return np.float64(0.0)

        # Lag-1 autocovariance with population-style normalization (divide by n).
        n_i = x.size
        gamma[i] = np.sum((x[:-1] - mu) * (x[1:] - mu)) / n_i

        # Blocking transform (pairwise averaging).
        x = 0.5 * (x[0::2] + x[1::2])

    weights = ((gamma / s) ** 2) * (2.0 ** np.arange(1, d + 1, dtype=np.float64)[::-1])
    m = np.cumsum(weights[::-1])[::-1]

    # Determine the stopping level k.
    k = 0
    while k < d and m[k] >= q[k]:
        k += 1

    if k >= d - 1:
        raise ValueError("need more data for SEM estimation")

    sem = np.sqrt(s[k] / (2.0 ** (d - k)))
    return np.float64(sem)
