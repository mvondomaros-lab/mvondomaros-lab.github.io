from __future__ import annotations

"""
Residence-time approach (RTA) utilities for bulk diffusion (constant PMF) in 1D.

Definitions (discrete-time trajectory x[k] sampled with timestep dt):

- Spatial interval (domain): Ω = [xmin, xmax)
- Inside indicator: I[k] = 1 if x[k] ∈ Ω, else 0
- Time origin: any time index k such that I[k] = 1
- Exit time at origin k: remaining time until the *first* exit from Ω
  (absorbing-boundary definition)

This module provides:
- Exit-time samples for all valid time origins
- Mean residence time τ_r and its SEM (via sem_corr)
- Bulk diffusivity estimate assuming constant PMF:
      D = (xmax - xmin)^2 / (12 τ_r)

Practical note (production MD):
  Discrete-time sampling introduces a systematic bias in first-exit observables. For production use, prefer
  dt -> 0 extrapolation via subsampling (see interval_diffusivity(..., extrapolation=...)).
"""

import typing
from typing import Iterable, Literal, Tuple

import numba
import numpy as np

from .stats import sem_corr

if typing.TYPE_CHECKING:
    from numpy.typing import NDArray


Extrapolation = Literal["none", "auto", "linear", "sqrt"]


@numba.njit(cache=True, fastmath=True)
def _count_inside_x(x: NDArray[np.float64], xmin: float, xmax: float) -> int:
    """
    Count the number of time origins, i.e., time steps k with x[k] ∈ Ω.

    :param x: Trajectory samples x[k].
    :param xmin: Lower bound of Ω (inclusive).
    :param xmax: Upper bound of Ω (exclusive).
    :returns: Number of valid time origins.
    """
    n_inside = 0
    for i in range(x.shape[0]):
        xi = x[i]
        if xi >= xmin and xi < xmax:
            n_inside += 1
    return n_inside


@numba.njit(cache=True, fastmath=True)
def interval_exit_times(
    x: NDArray[np.float64], xmin: float, xmax: float, dt: float
) -> NDArray[np.float64]:
    """
    Compute exit times from Ω = [xmin, xmax) for all valid time origins (mask-free implementation).

    Each exit time is measured from a time origin k such that x[k] ∈ Ω and represents
    the remaining time until the *first* exit from Ω (absorbing-boundary definition).
    Exit times are therefore conditional on being inside Ω at the time origin.

    Implementation detail:
      The trajectory is decomposed into contiguous inside segments of length m (in time steps).
      For each such segment, the following exit times are emitted:
          m·dt, (m-1)·dt, ..., 1·dt
      corresponding to choosing each time step in the segment as a time origin.

    Performance:
      This function avoids allocating a full inside/outside mask by evaluating membership on-the-fly.
      Two passes are used: (1) count inside frames to allocate output, (2) fill exit times.

    :param x: Trajectory samples x[k].
    :param xmin: Lower bound of Ω (inclusive).
    :param xmax: Upper bound of Ω (exclusive).
    :param dt: Time step between samples.
    :returns: Array of exit times (same units as dt), one per valid time origin.
              Returns an empty array if the trajectory never visits Ω.
    """
    n_inside = _count_inside_x(x, xmin, xmax)
    if n_inside == 0:
        return np.empty(0, dtype=np.float64)

    out = np.empty(n_inside, dtype=np.float64)
    idx = 0
    run_len = 0

    # Pass 2: scan and emit per inside segment
    for i in range(x.shape[0]):
        xi = x[i]
        inside = xi >= xmin and xi < xmax

        if inside:
            run_len += 1
        else:
            if run_len > 0:
                # Emit run_len, run_len-1, ..., 1 (frames) scaled by dt.
                for k in range(run_len):
                    out[idx + k] = (run_len - k) * dt
                idx += run_len
                run_len = 0

    # Flush final segment if the trajectory ends inside Ω.
    if run_len > 0:
        for k in range(run_len):
            out[idx + k] = (run_len - k) * dt
        idx += run_len

    return out


def interval_residence_time(
    x: NDArray[np.float64], xmin: float, xmax: float, dt: float
) -> Tuple[float, float]:
    """
    Compute the mean residence time τ_r in Ω = [xmin, xmax) and its SEM.

    The residence time is defined as the mean exit time, averaged over all valid
    time origins (all time steps k with x[k] ∈ Ω).

    The SEM is computed using sem_corr(...), which accounts for correlations in the
    exit-time samples via Jonsson's automated blocking method.

    :param x: Trajectory samples x[k].
    :param xmin: Lower bound of Ω (inclusive).
    :param xmax: Upper bound of Ω (exclusive).
    :param dt: Time step between samples.
    :returns: (mean_residence_time, residence_time_sem).
              Returns (NaN, NaN) if the trajectory never visits Ω.
              If the SEM cannot be estimated (e.g., insufficient data),
              the mean is returned with SEM = NaN.
    """
    times = interval_exit_times(x, xmin, xmax, dt)
    if times.size == 0:
        return float("nan"), float("nan")

    residence = float(times.mean())
    try:
        residence_sem = float(sem_corr(times))
    except ValueError:
        residence_sem = float("nan")

    return residence, residence_sem


def _interval_diffusivity_no_extrapolation(
    x: NDArray[np.float64], xmin: float, xmax: float, dt: float
) -> Tuple[float, float]:
    """
    Compute the single-dt bulk diffusivity estimate and its SEM.

    This is the baseline estimator:
        D = L^2 / (12 τ_r),
    with linear SEM propagation from τ_r.

    :param x: Trajectory samples x[k].
    :param xmin: Lower bound of Ω (inclusive).
    :param xmax: Upper bound of Ω (exclusive).
    :param dt: Time step between samples.
    :returns: (diffusivity, diffusivity_sem).
              Returns (NaN, NaN) if τ_r is undefined.
              If sem(τ_r) is undefined, diffusivity is returned with SEM = NaN.
    """
    residence, residence_sem = interval_residence_time(x, xmin, xmax, dt)
    if not np.isfinite(residence) or residence <= 0.0:
        return float("nan"), float("nan")

    L = float(xmax - xmin)
    pref = (L * L) / 12.0

    diff = pref / residence
    if not np.isfinite(residence_sem):
        return float(diff), float("nan")

    diff_sem = pref * residence_sem / (residence * residence)
    return float(diff), float(diff_sem)


def _wls_line(
    x: NDArray[np.float64],
    y: NDArray[np.float64],
    y_sem: NDArray[np.float64],
) -> Tuple[float, float, float, float]:
    """
    Fit y = a + b x using weighted least squares with Gaussian errors.

    This is a small internal utility used by dt -> 0 extrapolation in interval_diffusivity.
    Weights are taken as w = 1 / y_sem^2.

    :param x: Regressor values.
    :param y: Observations.
    :param y_sem: Standard errors of y (must be finite and positive).
    :returns: (a, b, a_sem, red_chi2), where a_sem is the SEM of the intercept and
              red_chi2 is the reduced chi^2 of the fit.
    """
    w = 1.0 / (y_sem * y_sem)
    X = np.column_stack([np.ones_like(x), x])

    XtWX = X.T @ (X * w[:, None])
    XtWy = X.T @ (y * w)

    beta = np.linalg.inv(XtWX) @ XtWy
    cov = np.linalg.inv(XtWX)

    a = float(beta[0])
    b = float(beta[1])
    a_sem = float(np.sqrt(cov[0, 0])) if np.isfinite(cov[0, 0]) else float("nan")

    r = y - (a + b * x)
    chi2 = float(np.sum((r / y_sem) ** 2))
    dof = int(y.size - 2)
    red_chi2 = float(chi2 / dof) if dof > 0 else float("nan")

    return a, b, a_sem, red_chi2


def interval_diffusivity(
    x: NDArray[np.float64],
    xmin: float,
    xmax: float,
    dt: float,
    *,
    extrapolation: Extrapolation = "none",
    strides: Iterable[int] = (1, 2, 4, 8, 16),
) -> Tuple[float, float]:
    """
    Compute the bulk diffusivity in Ω = [xmin, xmax) and its SEM.

    Base estimator (extrapolation="none"):
        D_est = L^2 / (12 τ_r),
    where τ_r is the mean first-exit (residence) time measured from the discretely sampled trajectory.

    Optional dt -> 0 extrapolation (extrapolation != "none"):
      First-exit observables are sensitive to time discretization because exits are detected only at sample
      times. A robust production remedy is to subsample the trajectory with stride s, yielding effective
      timesteps dt_s = s·dt, compute D_est(dt_s), and extrapolate dt_s -> 0.

      We fit in inverse space using weighted least squares:
          1 / D_est(dt_s) ≈ a + b f(dt_s)
      where:
        - extrapolation="linear": f(dt_s) = dt_s
        - extrapolation="sqrt":   f(dt_s) = sqrt(dt_s)
        - extrapolation="auto":   choose the better of the two fits by reduced chi^2

      The extrapolated diffusivity is D0 = 1/a.

    :param x: Trajectory samples x[k].
    :param xmin: Lower bound of Ω (inclusive).
    :param xmax: Upper bound of Ω (exclusive).
    :param dt: Time step between samples.
    :param extrapolation: "none", "auto", "linear", or "sqrt".
    :param strides: Subsampling strides used for dt -> 0 extrapolation (ignored if extrapolation="none").
    :returns: (diffusivity, diffusivity_sem).
              Returns (NaN, NaN) if τ_r is undefined or extrapolation cannot be performed.
              If SEM is undefined in the selected mode, diffusivity is returned with SEM = NaN.
    """
    if extrapolation == "none":
        return _interval_diffusivity_no_extrapolation(x, xmin, xmax, dt)

    if extrapolation not in ("auto", "linear", "sqrt"):
        raise ValueError("extrapolation must be 'none', 'auto', 'linear', or 'sqrt'")

    # Collect per-stride estimates using the base estimator at each effective timestep.
    rows = []
    for s in strides:
        s_int = int(s)
        if s_int <= 0:
            continue
        xs = x[::s_int]
        dt_s = float(dt * s_int)
        D_s, D_sem_s = _interval_diffusivity_no_extrapolation(xs, xmin, xmax, dt_s)
        rows.append((float(s_int), dt_s, float(D_s), float(D_sem_s)))

    table = np.array(rows, dtype=np.float64)
    if table.size == 0:
        return float("nan"), float("nan")

    # Keep only points with finite positive D and finite positive SEM for weighting.
    ok = (
        np.isfinite(table[:, 2])
        & (table[:, 2] > 0.0)
        & np.isfinite(table[:, 3])
        & (table[:, 3] > 0.0)
    )

    # Require at least 3 usable points for a meaningful line fit and diagnostics.
    if int(ok.sum()) < 3:
        return float("nan"), float("nan")

    dt_s = table[ok, 1]
    D_est = table[ok, 2]
    D_sem = table[ok, 3]

    # Fit y = 1/D with propagated SEMs
    y = 1.0 / D_est
    y_sem = D_sem / (D_est * D_est)  # sem(1/D) ≈ sem(D)/D^2

    # Candidate fits
    a_lin = a_lin_sem = red_lin = float("nan")
    a_sqrt = a_sqrt_sem = red_sqrt = float("nan")

    if extrapolation in ("auto", "linear"):
        a_lin, _, a_lin_sem, red_lin = _wls_line(dt_s, y, y_sem)

    if extrapolation in ("auto", "sqrt"):
        a_sqrt, _, a_sqrt_sem, red_sqrt = _wls_line(np.sqrt(dt_s), y, y_sem)

    # Choose fit
    if extrapolation == "linear":
        a, a_sem = a_lin, a_lin_sem
    elif extrapolation == "sqrt":
        a, a_sem = a_sqrt, a_sqrt_sem
    else:
        # auto: choose smaller reduced chi^2 (fallback to whichever is finite)
        if np.isfinite(red_lin) and np.isfinite(red_sqrt):
            if red_lin <= red_sqrt:
                a, a_sem = a_lin, a_lin_sem
            else:
                a, a_sem = a_sqrt, a_sqrt_sem
        elif np.isfinite(red_lin):
            a, a_sem = a_lin, a_lin_sem
        elif np.isfinite(red_sqrt):
            a, a_sem = a_sqrt, a_sqrt_sem
        else:
            return float("nan"), float("nan")

    # Intercept must be positive: a = 1/D0
    if not np.isfinite(a) or a <= 0.0:
        return float("nan"), float("nan")

    D0 = 1.0 / a
    if not np.isfinite(a_sem):
        return float(D0), float("nan")

    D0_sem = a_sem / (a * a)
    return float(D0), float(D0_sem)
