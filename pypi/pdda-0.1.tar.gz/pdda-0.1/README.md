# PDDA: Position-Dependent Diffusivity Analysis

[![made-with-python](https://img.shields.io/badge/Made%20with-Python-green.svg)](https://www.python.org/)
[![MIT license](https://img.shields.io/badge/License-MIT-green.svg)](https://lbesson.mit-license.org/)

**PDDA** is a Python library for estimating **position-dependent diffusivities** from molecular dynamics (MD)
trajectories in one dimension.
It is designed for practical analysis pipelines and emphasizes:

- clear, reproducible estimators,
- statistically meaningful uncertainty estimates (SEM for correlated data),
- production-friendly workflows (including time-discretization bias reduction).

## What PDDA provides

### Residence-time approach (RTA) for bulk diffusion in an interval

For a spatial interval $\Omega = [ x_\mathsf{min}, x_\mathsf{max})$ with constant PMF and constant diffusivity inside Ω,
PDDA implements the
residence-time identity

$$
D = \frac{(x_\mathsf{max} - x_\mathsf{min})^2}{12\tau_r},
$$

where $\tau_r$ is the mean **first-exit time** from $\Omega$, averaged over all time origins inside $\Omega$.

**Important (MD practice):** first-exit observables are sensitive to time discretization because exits are detected only
at sampled time points. PDDA therefore supports continuous-time extrapolation ($dt \to 0$) by subsampling the trajectory
and
extrapolating the estimate.

### Uncertainty estimates for correlated data

PDDA includes `sem_corr(...)`, an implementation of Jonsson’s automated blocking method for estimating the standard
error of the mean (SEM) from correlated time series:

- Jonsson, *Phys. Rev. E* **98**, 043304 (2018). https://doi.org/10.1103/PhysRevE.98.043304

## Quickstart

```python
from pdda.rta import interval_diffusivity

# x: 1D trajectory array sampled every dt (e.g., from MD)
dt = 0.01
xmin, xmax = 4.0, 6.0

# Single-dt estimate (fast, but may be biased by time discretization)
D_est, D_sem = interval_diffusivity(x, xmin, xmax, dt, extrapolation="none")

# Recommended for production MD: dt -> 0 extrapolation by subsampling
D0, D0_sem = interval_diffusivity(
    x, xmin, xmax, dt,
    extrapolation="auto",
    strides=(1, 2, 4, 8, 16),
)

print(D_est, D_sem)
print(D0, D0_sem)
```

## Tutorials / examples

- See the end-user demo notebook (`rta_demo.ipynb`) for a complete walkthrough on a controlled Brownian-motion system,
  including $dt \to 0$ extrapolation and diagnostics.

## Installation

See the project documentation:
https://mvondomaros-lab.github.io

## Citation

If you use PDDA in published work, please cite: *(placeholder until finalized)*

## License

MIT License. See `LICENSE`.
