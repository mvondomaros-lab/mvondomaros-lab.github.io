import numpy as np


def prevpow2(x: int | float) -> int:
    """
    Largest power of two less than or equal to abs(x).

    :param x: Input value.
    :return: Largest power of 2 <= abs(x). Returns 1 if abs(x) < 1.
    """
    n = int(abs(x))
    return 1 if n == 0 else 1 << (n.bit_length() - 1)


def _sem_iid(x: np.ndarray) -> float:
    """
    SEM of the mean assuming independent samples.

    Computes the standard error of the sample mean under the i.i.d. assumption:
        SEM = s / sqrt(n)
    where s is the sample standard deviation (ddof=1).

    :param x: 1D array of samples.
    :return: SEM of the sample mean (Python float).
    :raises ValueError: If x is not 1D, has <2 samples, or contains non-finite values.
    """
    if x.ndim != 1:
        raise ValueError("sem expects a 1D array")
    if x.size < 2:
        raise ValueError("need at least 2 samples for SEM estimation")
    if not np.all(np.isfinite(x)):
        raise ValueError("x contains non-finite values")

    s = float(np.std(x, ddof=1))
    return float(s / np.sqrt(x.size))


def _sem_corr_blocking(x: np.ndarray) -> float:
    """
    SEM of the mean for correlated time series (automated blocking).

    Implements Jonsson's automated blocking method:
        https://doi.org/10.1103/PhysRevE.98.043304

    The input is truncated to the largest power-of-two length. If the time series
    is too short to determine a stable blocking level, a ValueError is raised.

    :param x: 1D array of samples (correlated time series).
    :return: SEM of the sample mean (Python float).
    :raises ValueError: If x is not 1D, contains non-finite values, or is too short.
    """
    if x.ndim != 1:
        raise ValueError("sem expects a 1D array")
    if x.size < 4:
        raise ValueError("need at least 4 samples for correlated SEM estimation")
    if not np.all(np.isfinite(x)):
        raise ValueError("x contains non-finite values")

    n = prevpow2(x.size)
    if n < 4:
        raise ValueError("need more data for correlated SEM estimation")

    d = int(np.log2(n))
    x = np.asarray(x[:n], dtype=np.float64)

    q = np.array(
        [
            6.634897,
            9.210340,
            11.344867,
            13.276704,
            15.086272,
            16.811894,
            18.475307,
            20.090235,
            21.665994,
            23.209251,
            24.724970,
            26.216967,
            27.688250,
            29.141238,
            30.577914,
            31.999927,
            33.408664,
            34.805306,
            36.190869,
            37.566235,
            38.932173,
            40.289360,
            41.638398,
            42.979820,
            44.314105,
            45.641683,
            46.962942,
            48.278236,
            49.587884,
            50.892181,
        ],
        dtype=np.float64,
    )
    if d >= q.size:
        raise ValueError("need more data for correlated SEM estimation")

    s = np.zeros(d, dtype=np.float64)
    gamma = np.zeros(d, dtype=np.float64)

    # Pairwise-averaging preserves the mean for power-of-two lengths.
    mu = float(np.mean(x))

    for i in range(d):
        s[i] = np.var(x)  # ddof=0
        if s[i] == 0.0:
            return 0.0

        n_i = x.size
        gamma[i] = np.sum((x[:-1] - mu) * (x[1:] - mu)) / n_i
        x = 0.5 * (x[0::2] + x[1::2])

    weights = ((gamma / s) ** 2) * (2.0 ** np.arange(1, d + 1, dtype=np.float64)[::-1])
    m = np.cumsum(weights[::-1])[::-1]

    k = 0
    while k < d and m[k] >= q[k]:
        k += 1
    if k >= d - 1:
        raise ValueError("need more data for correlated SEM estimation")

    return float(np.sqrt(s[k] / (2.0 ** (d - k))))


def sem(x: np.ndarray, *, corr: bool = False) -> float:
    """
    Standard error of the mean (SEM).

    If corr=False (default), assumes independent samples:
        SEM = s / sqrt(n)

    If corr=True, accounts for temporal correlation using Jonsson's automated
    blocking method:
        https://doi.org/10.1103/PhysRevE.98.043304

    :param x: 1D array of samples.
    :param corr: If True, estimate SEM for correlated data (blocking). If False, i.i.d. SEM.
    :return: SEM of the sample mean (Python float).
    :raises ValueError: If x is invalid or (corr=True) there is insufficient data.
    """
    x = np.asarray(x, dtype=np.float64)
    return _sem_corr_blocking(x) if corr else _sem_iid(x)


# noinspection PyPep8Naming
def wls_line(
    x: np.ndarray, y: np.ndarray, y_sem: np.ndarray
) -> tuple[float, float, float]:
    """
    Weighted least-squares fit of a straight line: y ≈ a + b x.

    Assumes independent Gaussian errors with known standard errors y_sem.
    The weights are w = 1 / y_sem^2.

    :param x: 1D regressor values.
    :param y: 1D observations.
    :param y_sem: 1D standard errors of y (finite, strictly positive).
    :returns: (a, b, a_sem), where a_sem is the standard error of the intercept a.
    :raises ValueError: If inputs are invalid or the fit is ill-conditioned.
    """
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    y_sem = np.asarray(y_sem, dtype=np.float64)

    if x.ndim != 1 or y.ndim != 1 or y_sem.ndim != 1:
        raise ValueError("wls_line expects 1D arrays")
    if x.size != y.size or x.size != y_sem.size:
        raise ValueError("x, y, and y_sem must have the same length")
    if x.size < 2:
        raise ValueError("need at least 2 points to fit a line")
    if not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):
        raise ValueError("x or y contains non-finite values")
    if not np.all(np.isfinite(y_sem)) or np.any(y_sem <= 0.0):
        raise ValueError("y_sem must be finite and strictly positive")

    w = 1.0 / (y_sem * y_sem)
    X = np.column_stack([np.ones_like(x), x])

    XtWX = X.T @ (X * w[:, None])
    XtWy = X.T @ (y * w)

    try:
        beta = np.linalg.solve(XtWX, XtWy)
    except np.linalg.LinAlgError as e:
        raise ValueError("wls_line failed: normal equation matrix is singular") from e

    try:
        cov = np.linalg.inv(XtWX)
    except np.linalg.LinAlgError as e:
        raise ValueError("wls_line failed: cannot invert covariance matrix") from e

    a = float(beta[0])
    b = float(beta[1])
    a_var = float(cov[0, 0])
    a_sem = (
        float(np.sqrt(a_var)) if np.isfinite(a_var) and a_var >= 0.0 else float("nan")
    )
    return a, b, a_sem
