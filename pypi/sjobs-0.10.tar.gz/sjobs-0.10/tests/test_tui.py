"""Offline tests of the interactive watcher, driven with Textual's Pilot."""

import io
import json
import subprocess
import unittest
from unittest.mock import patch

import click
from rich.console import Console
from test_sjobs import (  # noqa: F401
    SNAPSHOT,
    script_output,
    setUpModule,
    tearDownModule,
)

from sjobs import sjobs, tui

SIZE = (140, 40)


def plain(renderable, width=100):
    """A Rich renderable (Text, Group, …) as plain text."""
    console = Console(width=width, file=io.StringIO(), record=True)
    console.print(renderable)
    return console.export_text()


def shown(app, selector):
    """Plain text of a Static in the app or its current screen."""
    return plain(app.screen.query_one(selector).content, width=250)


def ok(stdout=None):
    return subprocess.CompletedProcess([], 0, stdout=stdout or script_output())


class AppTestCase(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        which = patch("sjobs.sjobs.shutil.which", return_value="/usr/bin/squeue")
        which.start()
        self.addCleanup(which.stop)
        run = patch("sjobs.sjobs.subprocess.run", return_value=ok())
        self.run_mock = run.start()
        self.addCleanup(run.stop)

    async def settle(self, app, pilot):
        await app.workers.wait_for_complete()
        await pilot.pause()

    def headers(self, app, name):
        table = app.query_one(f"#table-{name}")
        return [str(column.label) for column in table.columns.values()]

    def footer(self, app):
        return " ".join(str(key.render()) for key in app.query("FooterKey"))

    def row_counts(self, app):
        return [table.row_count for table in app.tables()]


class TuiTests(AppTestCase):
    async def test_first_frame_uses_one_fetch(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            self.run_mock.assert_called_once()
            self.assertEqual(self.row_counts(app), [1, 2, 1])
            header = shown(app, "#where")
            self.assertIn("local · my jobs   using 16 CPUs · 16G · 1 GPU", header)
            self.assertIn("next in", shown(app, "#status"))
            self.assertNotIn("Path", self.headers(app, "RUNNING"))
            self.assertEqual(self.headers(app, "RUNNING")[1:3], ["Name", "Resources"])

    async def test_q_quits_without_jobs(self):
        # With every table hidden, focus must not stay on the hidden filter box.
        empty = json.dumps({"jobs": [], "errors": [], "warnings": []})
        self.run_mock.return_value = ok(script_output(squeue=empty))
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            self.assertEqual(self.row_counts(app), [0, 0, 0])
            await pilot.press("q")
            await pilot.pause()
            self.assertFalse(app.is_running)

    async def test_columns_toggle(self):
        app = tui.SjobsApp(columns=("nodes",))
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            self.assertIn("Nodes", self.headers(app, "RUNNING"))
            await pilot.press("o")
            self.assertIsInstance(app.screen, tui.ColumnChooser)
            # The list starts on "cwd", the second entry is "nodes".
            await pilot.press("space", "down", "space", "enter")
            self.assertIn("Path", self.headers(app, "RUNNING"))
            self.assertNotIn("Nodes", self.headers(app, "RUNNING"))
            self.run_mock.assert_called_once()

    async def test_arrows_continue_into_the_next_table(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            self.assertEqual(app.focused.id, "table-RUNNING")
            await pilot.press("down")
            self.assertEqual(app.focused.id, "table-PENDING")
            self.assertEqual(app.selected_job()["job_id"], "1200")
            await pilot.press("down", "down")
            self.assertEqual(app.focused.id, "table-OTHER")
            await pilot.press("down")
            self.assertEqual(app.focused.id, "table-OTHER")
            await pilot.press("up")
            self.assertEqual(app.focused.id, "table-PENDING")
            self.assertEqual(app.selected_job()["job_id"], "1100_[1-4]")

    async def test_narrow_windows_hide_columns_and_widening_shows_them(self):
        app = tui.SjobsApp(columns=("cwd", "nodes", "partition"))
        async with app.run_test(size=(60, 30)) as pilot:
            await self.settle(app, pilot)
            table = app.query_one("#table-RUNNING")
            headers = self.headers(app, "RUNNING")
            self.assertIn("Time left", headers)
            self.assertNotIn("Path", headers)
            self.assertNotIn("ID", headers)
            self.assertEqual(table.max_scroll_x, 0)
            self.assertIn("columns hidden", shown(app, "#label-RUNNING"))
            await pilot.resize_terminal(200, 30)
            await pilot.pause()
            await pilot.pause()
            self.assertIn("Path", self.headers(app, "RUNNING"))
            self.assertIn("ID", self.headers(app, "RUNNING"))
            self.assertNotIn("hidden", shown(app, "#label-RUNNING"))

    async def test_rules_stay_one_line_when_the_window_narrows(self):
        app = tui.SjobsApp()
        async with app.run_test(size=(200, 40)) as pilot:
            await self.settle(app, pilot)
            await pilot.resize_terminal(90, 40)
            await pilot.pause()
            for name in ("RUNNING", "PENDING"):
                label = app.query_one(f"#label-{name}")
                # One painted line, ending in the rule at the new width.
                lines = label.render_lines(label.region.reset_offset)
                text = "".join(segment.text for segment in lines[-1])
                self.assertEqual(label.content_size.height, 1)
                self.assertLessEqual(len(text.rstrip()), 90)
                self.assertTrue(text.rstrip().endswith("─"), text)

    async def test_filter_and_clear(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            # "q" goes into the filter instead of quitting.
            await pilot.press("slash", "q", "u", "e")
            self.assertEqual(app.filter_text, "que")
            self.assertEqual(self.row_counts(app), [0, 1, 0])
            self.assertIn("Pending · 1 of 2", shown(app, "#label-PENDING"))
            await pilot.press("escape")
            self.assertEqual(self.row_counts(app), [1, 2, 1])
            self.assertTrue(app.is_running)

    async def test_space_folds_arrays_and_enter_shows_details(self):
        payload = json.loads(SNAPSHOT)
        task = json.loads(json.dumps(payload["jobs"][0]))
        task["job_id"] = 1002
        task["array_task_id"]["number"] = 1
        payload["jobs"].append(task)
        self.run_mock.return_value = ok(script_output(json.dumps(payload)))
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            self.assertTrue(app.selected_job().get("_tasks"))
            self.assertIn("Expand", self.footer(app))
            self.assertNotIn("Fold", self.footer(app))
            folded = self.row_counts(app)
            # Enter opens the details even on a folded array row.
            await pilot.press("enter")
            self.assertTrue(app.preview_shown())
            await pilot.press("escape")
            self.assertFalse(app.preview_shown())
            self.assertEqual(self.row_counts(app), folded)
            # Space expands and folds again.
            await pilot.press("space")
            self.assertEqual(self.row_counts(app)[0], folded[0] + 1)
            self.assertIn("Fold", self.footer(app))
            self.assertNotIn("Expand", self.footer(app))
            # Fold works from any task of the array, not just the first.
            await pilot.press("down", "space")
            self.assertEqual(self.row_counts(app), folded)
            self.assertTrue(app.selected_job().get("_tasks"))
            # A plain job shows neither.
            await pilot.press("down")
            self.assertFalse(app.selected_job().get("_array_id"))
            self.assertNotIn("Expand", self.footer(app))
            self.assertNotIn("Fold", self.footer(app))

    async def test_enter_opens_details(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            self.assertFalse(app.preview_shown())
            self.assertIn("Details", self.footer(app))
            await pilot.press("enter")
            await pilot.pause()
            # Narrow but tall: below the tables, which keep the focus.
            self.assertEqual(app.preview_place(), "below")
            self.assertIsInstance(app.focused, tui.JobTable)
            text = shown(app, "#preview-body")
            self.assertIn("A100 (80GB)", text)
            self.assertIn("/scratch_shared/demo/run 01", text)
            # A running job's details start with when it ends.
            self.assertLess(text.index("Ends"), text.index("Resources"))
            # Enter again closes, as does Esc.
            await pilot.press("enter")
            self.assertFalse(app.preview_shown())
            await pilot.press("enter", "escape")
            self.assertFalse(app.preview_shown())

    async def test_short_windows_cover_the_tables(self):
        app = tui.SjobsApp()
        async with app.run_test(size=(100, tui.PREVIEW_MIN_HEIGHT - 1)) as pilot:
            await self.settle(app, pilot)
            await pilot.press("enter")
            await pilot.pause()
            self.assertEqual(app.preview_place(), "over")
            self.assertFalse(app.query_one("#tables").display)
            # Arrows still move through the jobs; the pane follows.
            await pilot.press("down")
            self.assertIn("Waiting", shown(app, "#preview-body"))
            await pilot.press("escape")
            await pilot.pause()
            self.assertTrue(app.query_one("#tables").display)

    async def test_cancel_needs_confirmation(self):
        app = tui.SjobsApp(host="cluster")
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            await pilot.press("c")
            self.assertIsInstance(app.screen, tui.ConfirmCancel)
            # The question is visible, not squeezed to nothing.
            question = app.screen.query_one("#dialog Static")
            self.assertGreater(question.region.width, 20)
            self.assertIn("Cancel job 1000_0", plain(question.content))
            await pilot.press("n")
            await self.settle(app, pilot)
            self.assertEqual(self.run_mock.call_count, 1)

            await pilot.press("c", "y")
            await self.settle(app, pilot)
            await self.settle(app, pilot)
            commands = [call.args[0] for call in self.run_mock.call_args_list]
            self.assertEqual(
                commands[1], sjobs.build_scancel_cmdline("1000_0", host="cluster")
            )
            # The cancel is followed by one refresh.
            self.assertEqual(len(commands), 3)

    async def test_failed_refresh_keeps_the_tables(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            self.run_mock.side_effect = subprocess.TimeoutExpired([], 60)
            app.refresh_jobs()
            await self.settle(app, pilot)
            self.assertEqual(self.row_counts(app), [1, 2, 1])
            self.assertIn("did not finish", shown(app, "#attention"))
            self.assertIn("update failed", shown(app, "#status"))

    async def test_manual_refresh_is_rate_limited(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            await pilot.press("r")
            await self.settle(app, pilot)
            self.run_mock.assert_called_once()
            app.last_request -= tui.MIN_MANUAL_REFRESH
            await pilot.press("r")
            await self.settle(app, pilot)
            self.assertEqual(self.run_mock.call_count, 2)

    async def test_all_users_refetches_without_me(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            await pilot.press("a")
            await self.settle(app, pilot)
            script = self.run_mock.call_args.args[0][2]
            self.assertNotIn("--me", script)
            self.assertIn("all users", shown(app, "#where"))
            # One row per user; yours (alice, from sshare) open with its jobs.
            rows = app.rows["RUNNING"]
            self.assertEqual(rows[0]["_group"], "alice")
            self.assertTrue(rows[1]["_indent"])
            # Space folds and opens a user's row; Enter shows details, as
            # on any row: here the user's totals.
            app.query_one("#table-RUNNING").focus()
            await pilot.press("space")
            self.assertEqual(len(app.rows["RUNNING"]), 1)
            await pilot.press("space")
            self.assertEqual(len(app.rows["RUNNING"]), 2)
            await pilot.press("enter")
            self.assertTrue(app.preview_shown())
            self.assertIn("Jobs", shown(app, "#preview-body"))
            await pilot.press("escape")
            self.assertEqual(len(app.rows["RUNNING"]), 2)
            # Your fair share stays in view, also with all users' jobs.
            self.assertIn("fair share low", shown(app, "#where"))


class FairShareTests(AppTestCase):
    async def test_fair_share_is_in_the_header_and_pending_details(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            self.assertIn("fair share low", shown(app, "#where"))
            self.assertNotIn("fair share", shown(app, "#label-PENDING"))
            pending = app.rows["PENDING"][0]
            text = plain(tui.detail_text(pending), width=200)
            self.assertIn("Fair share", text)
            self.assertIn("your jobs rank lower", text)


class ChangeTests(AppTestCase):
    async def test_changes_are_announced(self):
        app = tui.SjobsApp(config={"desktop_notifications": True})
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            started = script_output(
                SNAPSHOT.replace('"job_state": "PENDING"', '"job_state": "RUNNING"')
            )
            self.run_mock.return_value = ok(started)
            with (
                patch.object(app, "notify") as notify,
                patch.object(app, "desktop_notify") as desktop,
            ):
                app.refresh_jobs()
                await self.settle(app, pilot)
            self.assertIn("1200 queued started", notify.call_args_list[0].args[0])
            desktop.assert_called_once()

    async def test_short_windows_switch_to_tabs(self):
        app = tui.SjobsApp()
        async with app.run_test(size=(140, 10)) as pilot:
            await self.settle(app, pilot)
            self.assertTrue(app.tabbed)
            # t keeps the tables stacked, whatever the height.
            await pilot.press("t")
            self.assertFalse(app.tabbed)
            await pilot.resize_terminal(140, 9)
            await pilot.pause()
            self.assertFalse(app.tabbed)

    async def test_tabs_from_the_config(self):
        app = tui.SjobsApp(config={"layout": "tabs"})
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            self.assertTrue(app.tabbed)
            visible = [table.id for table in app.tables() if table.display]
            self.assertEqual(visible, ["table-RUNNING"])
            await pilot.press("2")
            visible = [table.id for table in app.tables() if table.display]
            self.assertEqual(visible, ["table-PENDING"])
            self.assertEqual(app.focused.id, "table-PENDING")


class ThemeTests(unittest.TestCase):
    REPLY = (
        b"\x1b]10;rgb:5858/6e6e/7575\x1b\\"
        b"\x1b]11;rgb:fdfd/f6f6/e3e3\x07"
        + b"".join(b"\x1b]4;%d;rgb:10/20/%02x\x1b\\" % (i, i) for i in range(16))
        + b"\x1b[?62;22c"
    )

    def test_color_reports_are_parsed(self):
        colors = tui.parse_color_reports(self.REPLY)
        self.assertEqual(colors["foreground"], "#586e75")
        self.assertEqual(colors["background"], "#fdf6e3")
        self.assertEqual(colors["palette"][4], "#102004")
        # Nothing reported: nothing known.
        empty = tui.parse_color_reports(b"\x1b[?62c")
        self.assertEqual(empty["palette"], [None] * 16)
        self.assertIsNone(empty["background"])

    def test_theme_from_the_terminal_colors(self):
        theme, ansi = tui.terminal_themes(tui.parse_color_reports(self.REPLY))
        self.assertFalse(theme.dark)
        self.assertEqual(theme.background, "#fdf6e3")
        self.assertEqual(theme.primary, "#102004")
        self.assertIsNotNone(ansi)
        self.assertEqual(tui.terminal_themes(None), (None, None))

    def test_auto_theme_falls_back_to_textual_themes(self):
        for colors, expected in (
            (tui.parse_color_reports(self.REPLY), tui.TERMINAL_THEME),
            (None, "textual-dark"),
            (
                {"background": "#ffffff", "foreground": None, "palette": [None] * 16},
                "textual-light",
            ),
        ):
            with self.subTest(expected=expected):
                app = tui.SjobsApp(terminal_colors=colors)
                app.apply_theme(tui.AUTO_THEME)
                self.assertEqual(app.theme, expected)
        app = tui.SjobsApp(config={"theme": "nord"})
        app.apply_theme("nord")
        self.assertEqual(app.theme, "nord")

    def test_ayu_themes_are_offered(self):
        for name in ("ayu-light", "ayu-mirage", "ayu-dark"):
            with self.subTest(name=name):
                app = tui.SjobsApp()
                app.apply_theme(name)
                self.assertEqual(app.theme, name)
                self.assertEqual(app.current_theme.dark, name != "ayu-light")


class DetailTests(unittest.TestCase):
    def test_help_explains_sjobs(self):
        text = plain(tui.HelpScreen(tui.SjobsApp.KEYS, 60).body, width=200)
        self.assertIn("Keys", text)
        self.assertIn("Marks", text)
        self.assertIn("Fair share", text)
        self.assertIn("refresh every 60 s", text)

    def test_details_skip_empty_fields(self):
        job = sjobs.normalize_job({"job_id": 7, "name": "x", "nodes": "", "a": []})
        text = plain(tui.detail_text(job))
        self.assertIn("ID", text)
        self.assertNotIn("Nodes", text)
        self.assertEqual(click.unstyle(text), text)

    def test_details_follow_the_situation(self):
        failed = sjobs.normalize_job(
            {"job_id": 8, "job_state": ["OUT_OF_MEMORY"], "tres_req_str": "mem=4G"}
        )
        text = plain(tui.detail_text(failed))
        self.assertTrue(text.startswith("Outcome"))
        self.assertIn("--mem", text)
        held = sjobs.normalize_job(
            {"job_id": 9, "job_state": ["PENDING"], "state_reason": "JobHeldUser"}
        )
        text = plain(tui.detail_text(held))
        self.assertTrue(text.startswith("Waiting"))
        self.assertIn("scontrol release 9", text)


class HistoryTests(AppTestCase):
    async def test_finished_jobs_stay_after_squeue_forgets_them(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            payload = json.loads(SNAPSHOT)
            # The completing job (1300) and the running task (1000_0) leave.
            payload["jobs"] = [
                job for job in payload["jobs"] if job["job_id"] not in (1300, 1001)
            ]
            self.run_mock.return_value = ok(script_output(json.dumps(payload)))
            app.refresh_jobs()
            await self.settle(app, pilot)
            finished = {row["job_id"]: row for row in app.rows["OTHER"]}
            self.assertEqual(set(finished), {"1300", "1000_0"})
            self.assertEqual(finished["1000_0"]["outcome"], "ended")
            self.assertIn("since today", shown(app, "#label-OTHER"))
            self.assertEqual(self.row_counts(app)[0], 0)
            # Switching to all users starts over, and back again forgets
            # nobody's jobs as ended: they only went out of view.
            await pilot.press("a")
            await self.settle(app, pilot)
            self.assertEqual(app.history, {})
            everyone = dict(payload)
            everyone["jobs"] = [
                *payload["jobs"],
                {
                    **next(j for j in payload["jobs"] if j["job_id"] == 1200),
                    "job_id": 1500,
                    "user_name": "bob",
                    "job_state": ["RUNNING"],
                },
            ]
            mine = ok(script_output(json.dumps(payload)))
            all_users = ok(script_output(json.dumps(everyone)))
            self.run_mock.side_effect = lambda cmd, **_: (
                mine if "--me" in cmd[-1] else all_users
            )
            app.last_request -= tui.MIN_MANUAL_REFRESH
            await pilot.press("r")
            await self.settle(app, pilot)
            ids = [job["job_id"] for job in app.snapshot["jobs"]]
            self.assertIn("1500", ids)
            await pilot.press("a")
            await self.settle(app, pilot)
            ids = [job["job_id"] for job in app.snapshot["jobs"]]
            self.assertNotIn("1500", ids)
            self.assertEqual(app.history, {})


class OptInTests(AppTestCase):
    SACCT = (
        "SJOBS_HOME=/home/a\n"
        f"{sjobs.SECTION_MARKER}sacct\n"
        "900|900|old-run|TIMEOUT|0:0|2026-11-12T00:00:00|2026-11-12T12:00:00"
        "|12:00:00|8|16G|/home/a/old|cpu|alice|node1\n"
    )

    def answer(self, cmdline, **_):
        script = cmdline[-1]
        if "sacct" in script:
            return ok(self.SACCT)
        sinfo = "batch|3/2/0/5|96/64/0/160\ngpu|10/0/1/11|500/0/20/520\n"
        return ok(
            script_output().replace(
                f"{sjobs.SECTION_MARKER}squeue",
                f"{sjobs.SECTION_MARKER}sinfo\n{sinfo}{sjobs.SECTION_MARKER}squeue",
            )
        )

    async def test_history_hours_fills_finished_from_sacct(self):
        self.run_mock.side_effect = self.answer
        app = tui.SjobsApp(config={"history_hours": 24})
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            await self.settle(app, pilot)
            scripts = [call.args[0][-1] for call in self.run_mock.call_args_list]
            self.assertEqual(sum("sacct" in script for script in scripts), 1)
            finished = {row["job_id"]: row for row in app.rows["OTHER"]}
            self.assertEqual(finished["900"]["outcome"], "timed out")
            self.assertEqual(finished["900"]["cwd"], "old")
            self.assertIn("since", shown(app, "#label-OTHER"))
            # Not for all users' jobs.
            await pilot.press("a")
            await self.settle(app, pilot)
            scripts = [call.args[0][-1] for call in self.run_mock.call_args_list]
            self.assertEqual(sum("sacct" in script for script in scripts), 1)
            self.assertNotIn("900", [row.get("job_id") for row in app.rows["OTHER"]])

    async def test_without_history_hours_there_is_no_sacct(self):
        self.run_mock.side_effect = self.answer
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            scripts = [call.args[0][-1] for call in self.run_mock.call_args_list]
            self.assertFalse(any("sacct" in script for script in scripts))
            self.assertFalse(any("sinfo" in script for script in scripts))

    async def test_idle_nodes_show_by_the_pending_jobs(self):
        self.run_mock.side_effect = self.answer
        app = tui.SjobsApp(config={"idle_nodes": True})
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            # Still one process per refresh, sinfo inside it.
            self.run_mock.assert_called_once()
            self.assertIn("sinfo", self.run_mock.call_args.args[0][-1])
            # Only in the details, not on the section line.
            self.assertNotIn("idle", shown(app, "#label-PENDING"))
            await pilot.press("down", "enter")
            self.assertIn(
                "batch: 64 CPUs free, 2 of 5 nodes idle", shown(app, "#preview-body")
            )


class CopyTests(AppTestCase):
    async def test_y_copies_the_job_id(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            with patch.object(app, "copy_to_clipboard") as copy:
                await pilot.press("y")
                copy.assert_called_once_with("1000_0")
                await pilot.press("enter", "y")
                self.assertEqual(copy.call_args.args[0], "1000_0")

    async def test_ctrl_c_quits(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            await pilot.press("ctrl+c")
            await pilot.pause()
            self.assertFalse(app.is_running)

    def test_mouse_capture_is_off(self):
        # The terminal's own selection then works, for copying IDs and paths.
        with (
            patch.object(tui, "query_terminal_colors", return_value=None),
            patch.object(tui.SjobsApp, "run") as run,
        ):
            tui.run_tui()
        run.assert_called_once_with(mouse=False)


class PaneTests(AppTestCase):
    async def test_wide_windows_show_the_details_pane(self):
        app = tui.SjobsApp()
        async with app.run_test(size=(tui.PREVIEW_MIN_WIDTH, 40)) as pilot:
            await self.settle(app, pilot)
            pane = app.query_one("#preview")
            # Off until asked for; the tables get the whole width.
            self.assertFalse(pane.has_class("shown"))
            await pilot.press("enter")
            self.assertTrue(pane.has_class("shown"))
            self.assertEqual(app.preview_place(), "side")
            self.assertIn("Ends", shown(app, "#preview-body"))
            await pilot.press("down")
            self.assertIn("Waiting", shown(app, "#preview-body"))
            # h checks the running job and shows the result in the pane.
            await pilot.press("up")
            self.run_mock.return_value = ok(
                f"{sjobs.SECTION_MARKER}now\n1794482019\n"
                f"{sjobs.SECTION_MARKER}sstat\n1001.batch|8G|01:00:00|1\n"
            )
            await pilot.press("h")
            await self.settle(app, pilot)
            self.assertIn("Memory peak", shown(app, "#preview-body"))
            self.assertIn("h checks output", shown(app, "#preview-hint"))
            # Pending jobs cannot be checked.
            await pilot.press("down", "h")
            await self.settle(app, pilot)
            self.assertEqual(self.run_mock.call_count, 2)
            # Narrower, the open pane moves below the tables.
            await pilot.resize_terminal(120, 40)
            await pilot.pause()
            await pilot.pause()
            self.assertEqual(app.preview_place(), "below")
            self.assertTrue(app.query_one("#main").has_class("below"))
            await pilot.press("enter")
            self.assertFalse(pane.has_class("shown"))

    async def test_empty_queue_says_so(self):
        empty = json.dumps({"jobs": [], "errors": [], "warnings": []})
        self.run_mock.return_value = ok(script_output(squeue=empty))
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            self.assertIn("no jobs in the queue", shown(app, "#empty"))
            self.assertIn("a shows all users", shown(app, "#empty"))

    async def test_h_checks_a_running_job(self):
        app = tui.SjobsApp()
        async with app.run_test(size=SIZE) as pilot:
            await self.settle(app, pilot)
            check = (
                f"{sjobs.SECTION_MARKER}now\n1794482019\n"
                f"{sjobs.SECTION_MARKER}log\n1794481839\n"
                f"{sjobs.SECTION_MARKER}sstat\n1001.batch|8G|01:00:00|1\n"
            )
            self.run_mock.return_value = ok(check)
            # h opens the details pane for its results.
            await pilot.press("h")
            await self.settle(app, pilot)
            await pilot.pause()
            self.assertTrue(app.preview_shown())
            text = shown(app, "#preview-body")
            self.assertIn("Output written  3m ago", text)
            self.assertIn("Memory peak     8G of 16G (50%)", text)
            script = self.run_mock.call_args.args[0][2]
            self.assertIn("sstat", script)


if __name__ == "__main__":
    unittest.main()
