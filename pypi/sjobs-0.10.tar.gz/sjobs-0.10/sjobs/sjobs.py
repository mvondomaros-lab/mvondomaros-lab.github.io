import json
import math
import os
import re
import shlex
import shutil
import subprocess
import sys
import time
import tomllib
from datetime import datetime
from pathlib import Path

import click
from rich.text import Text

MAX_CWD_WIDTH = 56
MAX_NAME_WIDTH = 32
MAX_TITLE_WIDTH = 48
MAX_NOTE_WIDTH = 24
MAX_JOB_ID_WIDTH = 20
MAX_REASON_WIDTH = 48
# Stop a hung SSH connection or squeue instead of leaving it on the login node.
SQUEUE_TIMEOUT = 60
# sjobs never polls the Slurm controller more often than this.
MIN_INTERVAL = 30
DEFAULT_INTERVAL = 60
PROGRESS_WIDTH = 10
BAR_DONE, BAR_LEFT = "━", "─"
SLURM_NO_VAL = 0xFFFFFFFE
# Columns shown only on request (--columns, `columns` in the config, or `o` in
# the interactive view), with a short description for the column chooser.
OPTIONAL_COLUMNS = {
    "cwd": "working directory",
    "nodes": "node names",
    "partition": "partition",
    "priority": "priority and its weighted factors (pending)",
}
# How the three tables share the window: one above the other, as tabs, or
# stacked while they fit (the default).
LAYOUTS = ("auto", "stacked", "tabs")
# Progress at or beyond this is highlighted: the job is about to hit its limit.
NEAR_LIMIT = 0.9
# Constraint features that look like GPU models: a100, a100_80gb, l40s, h200,
# rtxpro6000, mi250x. CPU or disk features (zen2, ssd_2tb, intel) do not match.
GPU_MODEL_RE = re.compile(
    r"(?:[ahlvpbt]\d{1,4}s?(?:_[\w.]+)?|rtx[\w.]*|gtx[\w.]*|mi\d+\w*|gh\d+)"
)
# Job IDs as displayed and as scancel accepts them: 12, 12_3, 12_[1-4,7], 12+1.
CANCELABLE_JOB_ID_RE = re.compile(r"\d+(?:_(?:\d+|\[[\d,\-%]+\]))?(?:\+\d+)?")

# Match squeue's display precedence when JSON includes both a base state and flags.
STATE_FLAGS = (
    "COMPLETING",
    "STAGE_OUT",
    "CONFIGURING",
    "RESIZING",
    "REQUEUED",
    "REQUEUE_FED",
    "REQUEUE_HOLD",
    "SPECIAL_EXIT",
    "STOPPED",
    "REVOKED",
    "RESV_DEL_HOLD",
    "SIGNALING",
)

HOST_ENV_VAR = "SJOBS_HOST"
CONFIG_ENV_VAR = "SJOBS_CONFIG"
# Printed before squeue over SSH so the remote home directory (as $HOME and as
# its physical path, which Slurm records for working directories) arrives with
# the same call.
REMOTE_HOME_MARKER = "SJOBS_HOME="
# Starts the output of one tool in the script; squeue always comes last.
SECTION_MARKER = "SJOBS_SECTION="

# Partition, nodes and CPUs as allocated/idle/other/total.
SINFO_FORMAT = "%R|%F|%C"
# Finished jobs from the accounting database, for `history_hours`.
SACCT_FIELDS = (
    "JobIDRaw",
    "JobID",
    "JobName",
    "State",
    "ExitCode",
    "Start",
    "End",
    "Timelimit",
    "AllocCPUS",
    "ReqMem",
    "WorkDir",
    "Partition",
    "User",
    "NodeList",
)
SACCT_STATES = "CD,F,TO,OOM,NF,BF,DL,CA,PR"
SSHARE_FIELDS = (
    "Account",
    "User",
    "RawShares",
    "NormShares",
    "RawUsage",
    "EffectvUsage",
    "FairShare",
)
# Job ID, user, partition, weighted total, then the weighted factors:
# age, fair share, job size, partition, QOS, TRES, nice.
SPRIO_FORMAT = "%i|%u|%r|%Y|%A|%F|%J|%P|%Q|%T|%N"
SPRIO_FACTORS = {"age": 4, "fs": 5, "size": 6, "part": 7, "qos": 8}
FACTOR_NAMES = {
    "age": "waiting time",
    "fs": "fair share",
    "size": "job size",
    "part": "partition",
    "qos": "QOS",
    "tres": "TRES",
}

CATEGORIES = {
    "RUNNING": {
        "title": "Running",
        "fields": [
            ("glyph", " "),
            ("title", "Name"),
            ("resources", "Resources"),
            ("progress", "Time left"),
            ("end_time", "Ends"),
            ("nodes", "Nodes"),
            ("partition", "Partition"),
            ("cwd", "Path"),
            ("job_id", "ID"),
        ],
        # Soonest to finish first.
        "sort": ("_end_time", "_job_id"),
    },
    "PENDING": {
        "title": "Pending",
        "fields": [
            ("glyph", " "),
            ("title", "Name"),
            ("resources", "Resources"),
            ("time_limit", "Limit"),
            ("waiting", "Waited"),
            ("est_start", "Starts"),
            ("partition", "Partition"),
            ("cwd", "Path"),
            ("priority", "Priority"),
            ("reason", "Why"),
            ("job_id", "ID"),
        ],
        # Highest priority first, then oldest submission.
        "sort": ("_priority", "_submit_time", "_job_id"),
    },
    "OTHER": {
        "title": "Finished",
        "fields": [
            ("glyph", " "),
            ("title", "Name"),
            ("outcome", "Outcome"),
            ("ran", "Ran"),
            ("ended", "Ended"),
            ("note", "Note"),
            ("partition", "Partition"),
            ("cwd", "Path"),
            ("job_id", "ID"),
        ],
        # Most recently ended first.
        "sort": ("_ended", "_job_id"),
    },
}
RIGHT_ALIGNED = {"time_limit", "waiting", "ran"}
# When a table is wider than the window, columns go in this order: the lowest
# number first. Columns not listed (the marker, the name, time left, why and
# outcome) always stay.
DROP_ORDER = {
    "cwd": 10,
    "nodes": 11,
    "priority": 12,
    "partition": 13,
    "job_id": 20,
    "time_limit": 30,
    "waiting": 40,
    "est_start": 41,
    "ran": 42,
    "resources": 50,
    "ended": 51,
    "note": 52,
    "end_time": 60,
}
# Columns that shrink (to this width) before any column is dropped.
SHRINK_TO = {"cwd": 16, "nodes": 8, "title": 16, "reason": 24}
# Columns that always show, even when every row is empty there.
ALWAYS_SHOWN = {"glyph", "title"}
# Styles use only the terminal's 16 ANSI colors, bold and named tokens, so they
# follow whatever light or dark palette the terminal has. Text is never yellow
# or cyan, which are faint on light backgrounds; those mark glyphs and bars.
# The app replaces "muted" with a gray made of the terminal's own colors.
STYLES = {
    "muted": "dim",
    "error": "bold red",
    "warn": "yellow",
    "ok": "green",
    "running": "green",
    "pending": "",
    "changed": "bold",
}

# Pending reasons as Slurm reports them, in words, with how serious they are:
# "error" means the job will not start without the user doing something.
PENDING_REASONS = {
    "Priority": ("in line", None),
    "Resources": ("next, waiting for free nodes", None),
    "BeginTime": ("waiting for its begin time", None),
    "JobArrayTaskLimit": ("array task limit (%) reached", None),
    "Reservation": ("waiting for its reservation", None),
    "ReqNodeNotAvail": ("needed nodes are down, drained or reserved", "warn"),
    "JobHeldUser": ("held by you", "warn"),
    "JobHeldAdmin": ("held by an administrator", "warn"),
    "launch failed requeued held": ("launch failed; requeued and held", "error"),
    "DependencyNeverSatisfied": ("dependency failed; will never start", "error"),
    "PartitionTimeLimit": ("time limit exceeds the partition's maximum", "error"),
    "PartitionNodeLimit": ("more nodes than the partition allows", "error"),
    "BadConstraints": ("constraints cannot be met", "error"),
    "InvalidQOS": ("invalid QOS", "error"),
    "InvalidAccount": ("invalid account", "error"),
    "None": ("", None),
}
# Reasons that only say the job waits its turn: shown faint, not as news.
ROUTINE_REASONS = {"Priority", "Resources", "None", ""}
# What to do about a pending reason, for the details.
REASON_HINTS = {
    "JobHeldUser": "Release it with `scontrol release {id}`.",
    "JobHeldAdmin": "Ask the cluster administrators why it is held.",
    "PartitionTimeLimit": "Ask for less time (--time) or use another partition.",
    "PartitionNodeLimit": "Ask for fewer nodes or use another partition.",
    "BadConstraints": "Check --constraint and the GPU or node features you ask for.",
    "InvalidQOS": "Check --qos; cancel and resubmit with a valid one.",
    "InvalidAccount": "Check --account; cancel and resubmit with a valid one.",
    "DependencyNeverSatisfied": "Cancel it, fix what it depends on, then resubmit.",
    "ReqNodeNotAvail": "It starts when the nodes come back, or ask for other nodes.",
    "Resources": "It has the highest priority and starts when nodes free up.",
    "Priority": "Jobs with a higher priority go first; it moves up while it waits.",
}
LIMIT_RESOURCES = {
    "Cpu": "CPU",
    "GRES": "GPU",
    "Mem": "memory",
    "Node": "node",
    "Job": "job count",
    "Jobs": "job count",
    "Wall": "time",
    "Billing": "billing",
    "Submit": "submit",
}
FINISHED_STATES = {
    "COMPLETED": ("completed", "ok"),
    "FAILED": ("failed", "error"),
    "TIMEOUT": ("timed out", "error"),
    "OUT_OF_MEMORY": ("out of memory", "error"),
    "NODE_FAIL": ("node failed", "error"),
    "BOOT_FAIL": ("boot failed", "error"),
    "DEADLINE": ("missed deadline", "error"),
    "CANCELLED": ("cancelled", "warn"),
    "PREEMPTED": ("preempted", "warn"),
}


def config_path():
    """Return the config file path, honoring SJOBS_CONFIG and XDG_CONFIG_HOME."""
    override = os.environ.get(CONFIG_ENV_VAR)
    if override:
        return Path(override).expanduser()

    base = os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config"
    return Path(base) / "sjobs" / "config.toml"


def load_config():
    """Load and validate the optional TOML config file."""
    path = config_path()

    try:
        with path.open("rb") as handle:
            config = tomllib.load(handle)
    except FileNotFoundError:
        return {}
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise click.ClickException(f"Failed to read config {path}: {exc}") from exc

    host = config.get("host")
    if host is not None and not (isinstance(host, str) and host):
        raise click.ClickException(f"Config {path}: 'host' must be a non-empty string")

    prefixes = config.get("path_prefixes", [])
    if not (
        isinstance(prefixes, list)
        and all(isinstance(prefix, str) and prefix for prefix in prefixes)
    ):
        raise click.ClickException(
            f"Config {path}: 'path_prefixes' must be a list of non-empty strings"
        )

    for key in ("idle_nodes",):
        if not isinstance(config.get(key, False), bool):
            raise click.ClickException(f"Config {path}: '{key}' must be true or false")

    hours = config.get("history_hours", 0)
    if isinstance(hours, bool) or not isinstance(hours, int) or not 0 <= hours <= 720:
        raise click.ClickException(
            f"Config {path}: 'history_hours' must be a whole number from 0 to 720"
        )

    notify = config.get("desktop_notifications", False)
    if not isinstance(notify, bool):
        raise click.ClickException(
            f"Config {path}: 'desktop_notifications' must be true or false"
        )

    theme = config.get("theme")
    if theme is not None and not (isinstance(theme, str) and theme):
        raise click.ClickException(f"Config {path}: 'theme' must be a non-empty string")

    layout = config.get("layout", "auto")
    if layout not in LAYOUTS:
        raise click.ClickException(
            f"Config {path}: 'layout' must be one of {', '.join(LAYOUTS)}"
        )

    for key, allowed in (("gpu_types", None), ("columns", list(OPTIONAL_COLUMNS))):
        values = config.get(key, [])
        if not (
            isinstance(values, list)
            and all(isinstance(value, str) and value for value in values)
        ):
            raise click.ClickException(
                f"Config {path}: '{key}' must be a list of non-empty strings"
            )
        unknown = [value for value in values if allowed and value not in allowed]
        if unknown:
            raise click.ClickException(
                f"Config {path}: unknown {key} {', '.join(unknown)} "
                f"(choose from {', '.join(allowed)})"
            )

    return config


def resolve_host(cli_host=None, config=None):
    """Pick the SSH host: --host, then SJOBS_HOST, then the config file."""
    if cli_host:
        return cli_host

    env_host = os.environ.get(HOST_ENV_VAR)
    if env_host:
        return env_host

    return (config or {}).get("host")


def local_homes():
    """The local home directory, as given and with symlinks resolved."""
    home = Path.home()
    return [str(home), str(home.resolve())]


def path_prefixes(config=None, homes=()):
    """Prefixes stripped from working directories: home directories plus config."""
    prefixes = []
    for prefix in [*homes, *(config or {}).get("path_prefixes", [])]:
        prefix = f"{prefix.rstrip('/')}/"
        if prefix != "/" and prefix not in prefixes:
            prefixes.append(prefix)
    return prefixes


def build_squeue_args(show_all=False, username=None):
    """Build the squeue arguments."""
    args = ["squeue", "--json", "--states=all"]

    if username:
        return args + [f"--user={username}"]

    if show_all:
        return args

    return args + ["--me"]


def optional_section(name, command):
    """Script step that prints a section marker, then a tool's output or why not.

    Its stderr joins its stdout so a failure becomes a note, never an error.
    """
    tool = command.split()[0]
    marker = shlex.quote(SECTION_MARKER + name)
    return (
        f"printf '%s\\n' {marker}; "
        f"if command -v {tool} >/dev/null 2>&1; then {command} 2>&1; "
        f"else printf '%s\\n' '{tool} not found'; fi"
    )


def build_script(show_all=False, username=None, idle=False):
    """Shell script: home markers, then sshare and sprio (and sinfo with
    `idle`), then squeue.

    squeue runs last, so its exit status and stderr decide success and
    everything after its marker is its JSON.
    """
    user = f"-u {shlex.quote(username)}" if username else '-u "$(id -un)"'
    sprio_user = "" if show_all and not username else f" {user}"
    home = shlex.quote(REMOTE_HOME_MARKER)
    return "; ".join(
        [
            (
                f"printf '%s%s\\n%s%s\\n' {home} \"$HOME\" {home} "
                '"$(cd 2>/dev/null && pwd -P)"'
            ),
            optional_section(
                "sshare", f"sshare -P -n -U -o {','.join(SSHARE_FIELDS)} {user}"
            ),
            optional_section(
                "sprio", f"sprio -h -o {shlex.quote(SPRIO_FORMAT)}{sprio_user}"
            ),
            *(
                [optional_section("sinfo", f"sinfo -h -o {shlex.quote(SINFO_FORMAT)}")]
                if idle
                else []
            ),
            f"printf '%s\\n' {shlex.quote(SECTION_MARKER + 'squeue')}",
            shlex.join(build_squeue_args(show_all=show_all, username=username)),
        ]
    )


def build_cmdline(show_all=False, username=None, host=None, idle=False):
    """Build the command: the script over SSH if a host is set, else locally."""
    script = build_script(show_all=show_all, username=username, idle=idle)

    if not host:
        if shutil.which("squeue"):
            return ["sh", "-c", script]
        raise click.ClickException(
            "squeue is not on PATH and no cluster host is configured. "
            f"Use --host, set {HOST_ENV_VAR}, or set 'host' in {config_path()}."
        )

    return ["ssh", host, shlex.join(["sh", "-lc", script])]


def run_command(cmdline, description, action):
    """Run a command with a timeout; every failure becomes a ClickException."""
    try:
        result = subprocess.run(
            cmdline,
            capture_output=True,
            text=True,
            check=True,
            timeout=SQUEUE_TIMEOUT,
        )
    except subprocess.TimeoutExpired as exc:
        raise click.ClickException(
            f"`{description}` did not finish within {SQUEUE_TIMEOUT} s"
        ) from exc
    except subprocess.CalledProcessError as exc:
        details = (
            (exc.stderr or "").strip()
            or split_sections(exc.stdout or "")[2].strip()
            or "unknown error"
        )
        raise click.ClickException(
            f"Failed to {action} with `{description}`: {details}"
        ) from exc
    except OSError as exc:
        raise click.ClickException(f"Failed to run `{cmdline[0]}`: {exc}") from exc

    return result.stdout


def run_squeue(show_all=False, username=None, host=None, idle=False):
    """Run the script and return stdout."""
    cmdline = build_cmdline(show_all=show_all, username=username, host=host, idle=idle)
    description = f"squeue on {host}" if host else "squeue"
    return run_command(cmdline, description, "fetch jobs")


def build_scancel_cmdline(job_id, host=None):
    """scancel for one displayed job ID, locally or over SSH.

    The ID must look like a Slurm job ID, so nothing else reaches a shell.
    """
    if not CANCELABLE_JOB_ID_RE.fullmatch(job_id or ""):
        raise click.ClickException(f"Not a job ID that scancel accepts: {job_id!r}")
    if not host:
        return ["scancel", job_id]
    return ["ssh", host, shlex.join(["sh", "-lc", shlex.join(["scancel", job_id])])]


def run_tail(path, host=None, lines=200):
    """The last lines of a job's output file, read where the job ran its tools."""
    command = ["tail", "-n", str(lines), "--", path]
    if host:
        command = ["ssh", host, shlex.join(["sh", "-lc", shlex.join(command)])]
    description = f"tail {path}" + (f" on {host}" if host else "")
    return run_command(command, description, "read the log")


def build_check_script(job):
    """Script that checks a running job: the clock, when its output file was
    last written, and what its steps use (sstat; the compute nodes answer,
    not the controller)."""
    job_id = unwrap_slurm_value((job.get("_raw") or {}).get("job_id"))
    if not isinstance(job_id, int):
        raise click.ClickException("This job has no job ID to check.")
    steps = []
    if job.get("_output"):
        steps.append(
            optional_section("log", f"stat -c %Y -- {shlex.quote(job['_output'])}")
        )
    steps.append(
        optional_section(
            "sstat", f"sstat -a -n -P -j {job_id} -o JobID,MaxRSS,AveCPU,NTasks"
        )
    )
    return "; ".join([optional_section("now", "date +%s"), *steps])


def run_check(job, host=None):
    """Check a running job; returns its rows for the details."""
    script = build_check_script(job)
    if host:
        cmdline = ["ssh", host, shlex.join(["sh", "-lc", script])]
    else:
        cmdline = ["sh", "-c", script]
    description = "job check" + (f" on {host}" if host else "")
    _homes, sections, _rest = split_sections(
        run_command(cmdline, description, "check the job")
    )
    return parse_check(sections, job)


def cpu_seconds(text):
    """sstat CPU time `[D-][HH:]MM:SS[.mmm]` in seconds; None if unreadable."""
    match = re.fullmatch(r"(?:(\d+)-)?(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)", text.strip())
    if not match:
        return None
    days, hours, minutes, seconds = match.groups()
    return (
        int(days or 0) * 86400
        + int(hours or 0) * 3600
        + int(minutes) * 60
        + float(seconds)
    )


def parse_check(sections, job):
    """Rows for the details from the check script's sections."""
    rows = []
    now_text = (sections.get("now") or "").strip()
    now = int(now_text) if now_text.isdigit() else time.time()
    log = (sections.get("log") or "").strip()
    if log.isdigit():
        rows.append(("Output written", format_age(int(log), now) or "just now"))
    elif "log" in sections:
        rows.append(("Output written", first_line(log) or "unknown"))

    peak = None
    cpu = 0.0
    seen = False
    for line in (sections.get("sstat") or "").splitlines():
        parts = line.strip().split("|")
        if len(parts) != 4:
            continue
        seen = True
        memory = tres_memory_mb(f"mem={parts[1]}")
        if memory is not None:
            peak = max(peak or 0, memory)
        seconds = cpu_seconds(parts[2])
        tasks = int(parts[3]) if parts[3].isdigit() else 1
        if seconds is not None:
            cpu += seconds * tasks
    if not seen:
        problem = first_line(sections.get("sstat"))
        rows.append(("Usage", problem or "no steps to measure yet"))
        return rows
    if peak is not None:
        usage = format_memory(peak)
        if job["_mem"]:
            usage += f" of {job['mem']} ({round(100 * peak / job['_mem'])}%)"
        rows.append(("Memory peak", usage))
    start = epoch((job.get("_raw") or {}).get("start_time"))
    if start and job["_cpus"] and now > start:
        share = round(100 * cpu / ((now - start) * job["_cpus"]))
        rows.append(("CPU use", f"{share}% of {plural(job['_cpus'], 'CPU')}"))
    return rows


def run_scancel(job_id, host=None):
    """Cancel one job; failures become a ClickException."""
    cmdline = build_scancel_cmdline(job_id, host)
    description = f"scancel {job_id}" + (f" on {host}" if host else "")
    run_command(cmdline, description, "cancel the job")


def parse_squeue_json(stdout):
    """Parse JSON output from squeue."""
    try:
        payload = json.loads(stdout)
    except json.JSONDecodeError as exc:
        raise click.ClickException(
            f"Failed to parse squeue JSON output: {exc}"
        ) from exc

    if not isinstance(payload, dict):
        raise click.ClickException("squeue JSON output was not an object")

    errors = payload.get("errors")
    if errors:
        if not isinstance(errors, list):
            errors = [errors]
        details = "; ".join(format_slurm_error(error) for error in errors)
        raise click.ClickException(f"squeue reported errors: {details}")

    jobs = payload.get("jobs")

    if jobs is None:
        raise click.ClickException("squeue JSON output did not contain a 'jobs' field")

    if not isinstance(jobs, list):
        raise click.ClickException("squeue JSON field 'jobs' was not a list")

    for index, job in enumerate(jobs):
        if not isinstance(job, dict):
            raise click.ClickException(
                f"squeue JSON job at index {index} was not an object"
            )

    return jobs


def format_slurm_error(error):
    """Retain both Slurm's error message and its diagnostic context."""
    if isinstance(error, dict):
        message = format_value(error.get("error"))
        description = format_value(error.get("description"))
        if message and description and message != description:
            return f"{message}: {description}"
        return message or description or format_value(error)
    return format_value(error)


def unwrap_slurm_value(value):
    """Unwrap common Slurm JSON scalar wrappers."""
    if not isinstance(value, dict):
        return value

    if {"set", "infinite", "number"}.issubset(value):
        if value.get("infinite"):
            return "infinite"
        if not value.get("set"):
            return ""
        return value.get("number")

    return value


def format_timestamp(value):
    """Format a Slurm epoch timestamp for display."""
    value = unwrap_slurm_value(value)

    if value in (None, "", 0):
        return ""

    if value == "infinite":
        return "infinite"

    try:
        return datetime.fromtimestamp(int(value)).strftime("%Y-%m-%d %H:%M")
    except (TypeError, ValueError, OverflowError, OSError):
        return format_value(value)


def primary_state(job):
    """Return the Slurm state displayed by squeue, including overriding flags."""
    states = job.get("job_state", [])
    if not isinstance(states, list):
        return format_value(states)

    for flag in STATE_FLAGS:
        if flag in states:
            return flag

    return format_value(states[0]) if states else ""


def format_job_id(job):
    """Preserve Slurm's array-task and heterogeneous-component identifiers."""
    array_id = unwrap_slurm_value(job.get("array_job_id"))
    if isinstance(array_id, int) and 0 < array_id < SLURM_NO_VAL:
        tasks = format_value(job.get("array_task_string"))
        if tasks:
            return f"{array_id}_[{tasks}]"

        task_id = unwrap_slurm_value(job.get("array_task_id"))
        if isinstance(task_id, int) and 0 <= task_id < SLURM_NO_VAL:
            return f"{array_id}_{task_id}"

    het_id = unwrap_slurm_value(job.get("het_job_id"))
    offset = unwrap_slurm_value(job.get("het_job_offset"))
    if (
        isinstance(het_id, int)
        and 0 < het_id < SLURM_NO_VAL
        and isinstance(offset, int)
        and 0 <= offset < SLURM_NO_VAL
    ):
        return f"{het_id}+{offset}"

    return format_value(job.get("job_id"))


def format_value(value):
    """Format a JSON value for table display."""
    value = unwrap_slurm_value(value)

    if value is None:
        return ""

    if isinstance(value, bool):
        return str(value).lower()

    if isinstance(value, (list, tuple)):
        return ",".join(format_value(item) for item in value)

    if isinstance(value, dict):
        return json.dumps(value, sort_keys=True)

    return str(value)


def strip_prefix(path, prefixes=None):
    """Remove the longest matching known prefix from a path."""
    path = format_value(path)

    if prefixes is None:
        prefixes = path_prefixes(homes=local_homes())

    for prefix in sorted(prefixes, key=len, reverse=True):
        if path.startswith(prefix):
            return path.removeprefix(prefix)

    return path


def truncate_left(text, max_width):
    """Left-truncate text to max_width characters, keeping the tail."""
    if len(text) <= max_width:
        return text

    return "…" + text[-(max_width - 1) :]


def shorten_path(path, prefixes=None, max_width=MAX_CWD_WIDTH):
    """Strip a known prefix, then left-truncate long paths keeping the tail."""
    return truncate_left(strip_prefix(path, prefixes), max_width)


def format_gpu_type(gpu_type):
    """Format a Slurm GPU type for display."""
    if not gpu_type:
        return "GPU"

    gpu_type = gpu_type.strip().lower()

    memory_match = re.search(r"_(\d+)gb$", gpu_type)
    memory = memory_match.group(1) if memory_match else None

    if memory:
        gpu_type = gpu_type[: memory_match.start()]

    name = gpu_type.replace("_", " ").upper()

    if memory:
        return f"{name} ({memory}GB)"

    return name


def format_gpus(tres_per_job):
    """Format GPU requests from a Slurm TRES string."""
    tres_per_job = format_value(tres_per_job)

    if not tres_per_job:
        return ""

    gpus = []

    for item in tres_per_job.split(","):
        parts = item.strip().split(":")
        if parts[0] not in {"gres/gpu", "gpu"}:
            continue

        if len(parts) == 2:
            gpu_type = ""
            count = parts[1]
        elif len(parts) >= 3:
            gpu_type = ":".join(parts[1:-1])
            count = parts[-1]
        else:
            continue

        gpus.append(f"{count} x {format_gpu_type(gpu_type)}")

    return ", ".join(gpus)


def format_gpu_totals(tres_str):
    """Format job-total GPUs from a TRES count string such as tres_alloc_str.

    Slurm lists a generic `gres/gpu=N` and, when known, typed
    `gres/gpu:<type>=N` entries; typed entries are preferred.
    """
    tres_str = format_value(tres_str)
    typed = []
    generic = None

    for item in tres_str.split(","):
        name, sep, count = item.strip().partition("=")
        if not sep:
            continue
        if name == "gres/gpu":
            generic = count
        elif name.startswith("gres/gpu:"):
            typed.append(f"{count} x {format_gpu_type(name.removeprefix('gres/gpu:'))}")

    if typed:
        return ", ".join(typed)
    if generic and generic != "0":
        return f"{generic} x GPU"
    return ""


def format_gres_detail(detail):
    """Typed GPUs from gres_detail (`gpu:a100:1(IDX:0)`, one entry per node)."""
    counts = {}
    for entry in detail if isinstance(detail, list) else []:
        match = re.match(r"gpu:([^:(]+):(\d+)", format_value(entry))
        if match:
            gpu_type, count = match.groups()
            counts[gpu_type] = counts.get(gpu_type, 0) + int(count)
    return ", ".join(
        f"{count} x {format_gpu_type(gpu_type)}" for gpu_type, count in counts.items()
    )


def gpu_types_from_features(features, known=()):
    """GPU models named in a job's constraint, e.g. `a100|a40&ssd_2tb`.

    Jobs that ask for an untyped `--gpus N` often pick the model this way.
    `known` adds model names that GPU_MODEL_RE does not recognize.
    """
    known = {name.lower() for name in known}
    models = []
    for token in re.split(r"[&|,\[\]()]", format_value(features)):
        token = re.sub(r"\*\d+$", "", token.strip()).lower()
        is_model = token in known or GPU_MODEL_RE.fullmatch(token)
        if token and is_model and token not in models:
            models.append(token)
    return models


def format_gpu_requests(job, gpu_types=()):
    """Show allocated GPUs when known, otherwise each request with its scope.

    The allocation (tres_alloc_str, else gres_detail) names the GPU type
    actually assigned. Before allocation, scoped requests are shown without
    adding overlapping limits; tres_req_str is the last fallback. An untyped
    count takes its models from the job's constraint, if it names any.
    """
    gpus = format_gpu_totals(job.get("tres_alloc_str"))
    if not gpus or " x GPU" in gpus:
        gpus = format_gres_detail(job.get("gres_detail")) or gpus

    if not gpus:
        requests = []
        for scope in ("job", "node", "socket", "task"):
            scoped = format_gpus(job.get(f"tres_per_{scope}"))
            if scoped:
                requests.append(scoped if scope == "job" else f"{scoped} / {scope}")
        gpus = "; ".join(requests) or format_gpu_totals(job.get("tres_req_str"))

    models = gpu_types_from_features(job.get("features"), gpu_types)
    if models and " x GPU" in gpus:
        names = "|".join(format_gpu_type(model) for model in models)
        gpus = re.sub(r" x GPU\b", f" x {names}", gpus)
    return gpus


def sort_number(value):
    """Return a positive Slurm number for sorting, or infinity if unset."""
    value = unwrap_slurm_value(value)
    if (
        isinstance(value, int)
        and not isinstance(value, bool)
        and 0 < value < SLURM_NO_VAL
    ):
        return value
    return float("inf")


def epoch(value):
    """Return a set Slurm timestamp in seconds, or None."""
    value = unwrap_slurm_value(value)
    if (
        isinstance(value, int)
        and not isinstance(value, bool)
        and 0 < value < SLURM_NO_VAL
    ):
        return value
    return None


def time_limit_seconds(value):
    """Slurm time limit (minutes) in seconds; math.inf if unlimited, None if unset."""
    value = unwrap_slurm_value(value)
    if value == "infinite":
        return math.inf
    if (
        isinstance(value, int)
        and not isinstance(value, bool)
        and 0 < value < SLURM_NO_VAL
    ):
        return value * 60
    return None


def format_duration(seconds):
    """Compact duration: <1m, 45m, 3h12m, 1d04h."""
    if seconds is None:
        return ""
    if seconds == math.inf:
        return "unlimited"
    if seconds < 60:
        return "<1m"
    minutes = int(seconds // 60)
    days, minutes = divmod(minutes, 24 * 60)
    hours, minutes = divmod(minutes, 60)
    if days:
        return f"{days}d{hours:02d}h"
    if hours:
        return f"{hours}h{minutes:02d}m"
    return f"{minutes}m"


def format_age(timestamp, now):
    """How long ago a timestamp was, e.g. `2h05m ago`."""
    if timestamp is None or timestamp > now:
        return ""
    return f"{format_duration(now - timestamp)} ago"


def format_until(timestamp, now):
    """How long until a timestamp: `in 3h12m`, `now`; "" if unknown or past."""
    if timestamp is None or timestamp <= now:
        return ""
    if timestamp - now < 60:
        return "now"
    return f"in {format_duration(timestamp - now)}"


def format_when(timestamp, now):
    """Timestamp relative to today: `today 18:05`, `Thu 09:12`, else the date."""
    if timestamp is None:
        return ""
    try:
        when = datetime.fromtimestamp(timestamp)
        today = datetime.fromtimestamp(now).date()
    except (OverflowError, OSError, ValueError):
        return format_value(timestamp)
    days = (when.date() - today).days
    if days == 0:
        return f"today {when:%H:%M}"
    if days == 1:
        return f"tomorrow {when:%H:%M}"
    if days == -1:
        return f"yesterday {when:%H:%M}"
    if abs(days) < 7:
        return f"{when:%a %H:%M}"
    return f"{when:%Y-%m-%d %H:%M}"


def progress_bar(fraction, width=PROGRESS_WIDTH):
    """A thin bar for the share of the time limit used, e.g. `━━━───────`."""
    fraction = min(max(fraction, 0.0), 1.0)
    filled = round(fraction * width)
    return BAR_DONE * filled + BAR_LEFT * (width - filled)


def gpu_count(tres_str):
    """Number of GPUs in a TRES count string such as tres_alloc_str."""
    generic = 0
    typed = 0
    for item in format_value(tres_str).split(","):
        name, sep, count = item.strip().partition("=")
        if not sep or not count.isdigit():
            continue
        if name == "gres/gpu":
            generic = int(count)
        elif name.startswith("gres/gpu:"):
            typed += int(count)
    return generic or typed


def first_line(text):
    """First non-blank line of text, shortened for a note; None if blank."""
    for line in (text or "").splitlines():
        if line.strip():
            return truncate_right(line.strip(), 80)
    return None


def parse_sshare(text):
    """Parse `sshare -P -n -U -o SSHARE_FIELDS` rows into (rows, problem).

    `problem` is a short reason when the text held output but no rows.
    """
    rows = []
    for line in (text or "").splitlines():
        parts = line.strip().split("|")
        if len(parts) != len(SSHARE_FIELDS) or not parts[1]:
            continue
        try:
            fairshare = float(parts[6])
        except ValueError:
            continue
        rows.append({"account": parts[0], "user": parts[1], "fairshare": fairshare})
    return rows, None if rows else first_line(text)


def parse_sprio(text):
    """Parse `sprio -h -o SPRIO_FORMAT` rows into ({job_id: entry}, problem).

    A job pending in several partitions keeps its highest-priority row.
    """
    priorities = {}
    for line in (text or "").splitlines():
        parts = [part.strip() for part in line.split("|")]
        if len(parts) != SPRIO_FORMAT.count("|") + 1:
            continue
        job_id = re.match(r"\d+", parts[0])
        if not job_id:
            continue
        try:
            priority = float(parts[3])
            factors = {
                name: float(parts[index] or 0) for name, index in SPRIO_FACTORS.items()
            }
        except ValueError:
            continue
        factors["tres"] = sum(map(float, re.findall(r"=([\d.]+)", parts[9])))
        job_id = int(job_id.group())
        if job_id not in priorities or priority > priorities[job_id]["priority"]:
            priorities[job_id] = {"priority": priority, "factors": factors}
    return priorities, None if priorities else first_line(text)


def format_factors(factors):
    """Each factor's share of the priority, largest first.

    `waiting time 75%, fair share 20%`.
    """
    total = sum(value for value in factors.values() if value > 0)
    if total <= 0:
        return ""
    shares = sorted(
        (-round(100 * value / total), name) for name, value in factors.items()
    )
    return ", ".join(
        f"{FACTOR_NAMES.get(name, name)} {-share}%"
        for share, name in shares
        if share <= -1
    )


def tres_memory_mb(tres_str):
    """Memory in MB from a TRES string such as `cpu=4,mem=16G`; None if absent."""
    for item in format_value(tres_str).split(","):
        name, _sep, value = item.strip().partition("=")
        match = re.fullmatch(r"([\d.]+)([KMGT]?)", value) if name == "mem" else None
        if match:
            scale = {"K": 1 / 1024, "": 1, "M": 1, "G": 1024, "T": 1024**2}
            return float(match.group(1)) * scale[match.group(2)]
    return None


def format_memory(mb):
    """`512M`, `3.9G`, `16G`, `1.5T`."""
    if mb is None:
        return ""
    for unit, size in (("T", 1024**2), ("G", 1024)):
        if mb >= size:
            value = mb / size
            return (
                f"{value:.0f}{unit}"
                if value >= 10 or value.is_integer()
                else (f"{value:.1f}{unit}")
            )
    return f"{mb:.0f}M"


def format_exit_code(code):
    """Exit code of a finished job: `0`, `1`, `SIGKILL`; "" if unknown."""
    if isinstance(code, dict):
        signal = code.get("signal") or {}
        name = format_value(signal.get("name"))
        if name:
            return name
        signal_id = unwrap_slurm_value(signal.get("id"))
        if isinstance(signal_id, int) and 0 < signal_id < SLURM_NO_VAL:
            return f"signal {signal_id}"
        code = code.get("return_code")
    code = unwrap_slurm_value(code)
    if isinstance(code, int) and not isinstance(code, bool) and code < SLURM_NO_VAL:
        return str(code)
    return ""


def describe_dependency(dependency):
    """`afterok:12_*(unfulfilled),afterany:13` -> `after 12_* ok, after 13`."""
    kinds = {"afterok": "ok", "afternotok": "fails", "aftercorr": "ok, per task"}
    parts = []
    for item in format_value(dependency).split(","):
        item = re.sub(r"\((unfulfilled|failed)\)$", "", item.strip())
        kind, _sep, ids = item.partition(":")
        if not ids:
            if item:
                parts.append(item)
            continue
        ids = ids.replace(":", ", ")
        suffix = kinds.get(kind)
        parts.append(f"after {ids} {suffix}" if suffix else f"after {ids}")
    return ", ".join(parts)


def describe_reason(reason, dependency=""):
    """A pending reason in words, and its severity (None, "warn" or "error")."""
    reason = format_value(reason)
    if reason == "Dependency":
        return f"waits for: {describe_dependency(dependency)}", None
    if reason == "DependencyNeverSatisfied" and dependency:
        text = describe_dependency(dependency)
        return f"dependency failed ({text}); will never start", "error"
    if reason in PENDING_REASONS:
        return PENDING_REASONS[reason]

    match = re.fullmatch(
        r"(QOS|Assoc)(Grp|Max)([A-Za-z]+?)(PerUser|PerAccount|PerJob|PerNode)?"
        r"(RunMinutes|Minutes)?(Limit)?",
        reason,
    )
    if match and match.group(3) in LIMIT_RESOURCES:
        owner, kind, resource, scope = match.group(1, 2, 3, 4)
        resource = LIMIT_RESOURCES[resource]
        if match.group(5):
            resource = f"{resource}-minutes"
        whose = {
            "PerUser": "your",
            "PerAccount": "the account's",
            "PerJob": "per-job",
            "PerNode": "per-node",
        }.get(scope, "the group's" if kind == "Grp" else "the")
        where = "QOS" if owner == "QOS" else "account"
        return f"{whose} {resource} limit ({where}) reached", None
    return reason, None


def compact_gpus(gpus):
    """`1 x A100 (80GB)` -> `A100·80GB`, `2 x GPU / node` -> `2×GPU/node`."""
    text = re.sub(r" \((\d+GB)\)", r"·\1", gpus)
    text = re.sub(r"\b1 x ", "", text)
    text = re.sub(r"(\d+) x ", r"\1×", text)
    return text.replace(" / ", "/").replace("; ", ", ")


def format_resources(cpus, memory, gpus):
    """One compact cell: `16c 16G A100·80GB`."""
    parts = []
    if cpus:
        parts.append(f"{cpus}c")
    if memory:
        parts.append(memory)
    if gpus:
        parts.append(compact_gpus(gpus))
    return " ".join(parts)


def count_tasks(task_string):
    """Number of tasks in an array task string: `1-4,7%2` -> 5, `0-9:2` -> 5."""
    total = 0
    for part in format_value(task_string).split("%")[0].split(","):
        match = re.fullmatch(r"(\d+)(?:-(\d+)(?::(\d+))?)?", part.strip())
        if match:
            first, last, step = match.groups()
            last = int(last) if last else int(first)
            total += len(range(int(first), last + 1, int(step or 1)))
    return total


def explain_outcome(job):
    """Why a finished job ended as it did: (short note, advice for the details)."""
    state = job["state"].upper()
    exit_code = job["exit"]
    if state == "TIMEOUT":
        limit = job["time_limit"]
        return (
            f"limit was {limit}" if limit else "hit its time limit",
            (
                "It ran out of time. Ask for more (--time), or save and resume "
                "from checkpoints."
            ),
        )
    if state == "OUT_OF_MEMORY":
        mem = job["mem"]
        return (
            f"requested {mem}" if mem else "needed more memory",
            (
                "It used more memory than it asked for. Ask for more (--mem or "
                "--mem-per-cpu)."
            ),
        )
    if state == "FAILED":
        return (
            "l shows the log",
            (
                f"The script exited with {exit_code or 'an error'}. The end of its "
                "output or error file (l) usually says why."
            ),
        )
    if state in ("NODE_FAIL", "BOOT_FAIL"):
        return "not your fault", "A node failed under it. Resubmit it."
    if state == "PREEMPTED":
        return "make way", "A higher-priority job took its nodes. Resubmit it."
    if state == "DEADLINE":
        return "", "It could not finish before its --deadline."
    return "", ""


def outcome_text(job):
    """State and exit code in one: `failed (exit 1)`, `completed`."""
    label = job["state_label"]
    code = job["exit"]
    if code and code != "0" and job["state"].upper() != "CANCELLED":
        return f"{label} (exit {code})" if code.isdigit() else f"{label} ({code})"
    return label


def dependency_targets(dependency):
    """`afterok:12_*(unfulfilled),singleton` -> [("afterok", "12_*"), ("singleton", "")]."""
    targets = []
    for item in format_value(dependency).split(","):
        item = re.sub(r"\((unfulfilled|failed)\)$", "", item.strip())
        kind, _sep, ids = item.partition(":")
        if not ids:
            if kind:
                targets.append((kind, ""))
            continue
        for target in ids.split(":"):
            # A trailing `+N` is a delay in minutes, not part of the ID.
            targets.append((kind, re.sub(r"\+\d+$", "", target)))
    return targets


DEPENDENCY_WORDS = {
    "afterok": " succeeds",
    "afternotok": " fails",
    "aftercorr": " succeeds, task by task",
    "after": " starts",
    "afterany": " ends",
    "afterburstbuffer": " ends",
}


def resolve_dependencies(jobs, now):
    """Name the jobs pending jobs wait for, with their state or end time.

    `after md run succeeds (ends today 18:13)` instead of `afterok:1000_*`.
    Jobs no longer in the queue keep their ID.
    """
    by_id = {}
    for job in jobs:
        raw = job.get("_raw") or {}
        for key in (raw.get("job_id"), job.get("_array_job")):
            key = unwrap_slurm_value(key)
            if isinstance(key, int):
                by_id.setdefault(str(key), []).append(job)
    for job in jobs:
        raw = job.get("_raw") or {}
        if format_value(raw.get("state_reason")) != "Dependency":
            continue
        parts = []
        for kind, target in dependency_targets(raw.get("dependency")):
            if not target:
                parts.append(
                    "other jobs with its name (singleton)"
                    if kind == "singleton"
                    else kind
                )
                continue
            base, _sep, task = target.partition("_")
            matches = by_id.get(base, [])
            if task and task != "*":
                matches = [m for m in matches if m["job_id"] == target] or matches
            words = DEPENDENCY_WORDS.get(kind, "")
            if not matches:
                parts.append(f"after {target}{words}")
                continue
            name = matches[0]["name"] or target
            categories = {classify_job(m) for m in matches}
            if "PENDING" in categories:
                status = "pending"
            elif "RUNNING" in categories:
                ends = [
                    m["_end_time"]
                    for m in matches
                    if classify_job(m) == "RUNNING" and m["_end_time"] != math.inf
                ]
                status = f"ends {format_when(max(ends), now)}" if ends else "running"
            else:
                status = matches[0]["state_label"]
            parts.append(f"after {name}{words} ({status})")
        if parts:
            job["reason"] = ", ".join(parts)


def array_summaries(jobs):
    """How far each array job has got: {array ID: `2/4 done`}.

    Counts the tasks of every row the view knows, finished ones included.
    """
    counts = {}
    for job in jobs:
        array_id = job.get("_array_job")
        if array_id is None:
            continue
        tally = counts.setdefault(array_id, {"total": 0, "done": 0, "failed": 0})
        raw = job.get("_raw") or {}
        tasks = count_tasks(raw.get("array_task_string")) or 1
        tally["total"] += tasks
        if classify_job(job) == "OTHER":
            if job["_severity"] == "ok":
                tally["done"] += tasks
            elif job["_severity"] == "error":
                tally["failed"] += tasks
    summaries = {}
    for array_id, tally in counts.items():
        if tally["total"] < 2:
            continue
        text = f"{tally['done']}/{tally['total']} done"
        if tally["failed"]:
            text += f", {tally['failed']} failed"
        summaries[array_id] = text
    return summaries


def disambiguate(jobs):
    """Set `_where`, the end of the path, for jobs whose name is not unique.

    Ten jobs called `run.sh` are told apart by their directories.
    """
    by_name = {}
    for job in jobs:
        job["_where"] = ""
        by_name.setdefault(job["name"], []).append(job)
    for same in by_name.values():
        paths = {job["cwd"] for job in same}
        if len(paths) < 2:
            continue
        for depth in (1, 2, 3):
            tails = {
                job["cwd"]: "/".join(job["cwd"].rstrip("/").split("/")[-depth:])
                for job in same
            }
            if len(set(tails.values())) == len(paths):
                break
        for job in same:
            job["_where"] = tails[job["cwd"]]


# Status markers in front of each row, by category and severity, with style
# names from STYLES.
GLYPHS = {
    "RUNNING": ("●", "running"),
    "PENDING": ("○", "muted"),
    "error": ("✗", "error"),
    "warn": ("!", "warn"),
    "ok": ("✓", "ok"),
    "OTHER": ("·", "muted"),
}


def resolve_style(name):
    """A style name from STYLES, or the style itself."""
    return STYLES.get(name, name)


def status_glyph(category, severity):
    """The marker and its style for a job: ● running, ○ pending, ✓ done, …"""
    if category == "PENDING" and severity:
        return GLYPHS[severity if severity == "error" else "warn"]
    if category == "OTHER" and severity:
        return GLYPHS[severity]
    return GLYPHS[category]


def normalize_job(job, prefixes=None, now=None, priorities=None, gpu_types=()):
    """Normalize one squeue JSON job into display fields.

    `cwd` keeps the full prefix-stripped path; rendering truncates it to fit.
    `priorities` maps job IDs to parsed sprio entries; `gpu_types` adds GPU
    model names to look for in constraints.
    Keys starting with an underscore are sort keys, totals and the raw job
    (`_raw`), not display fields.
    """
    now = time.time() if now is None else now
    start = epoch(job.get("start_time"))
    end = epoch(job.get("end_time"))
    submit = epoch(job.get("submit_time"))
    limit = time_limit_seconds(job.get("time_limit"))
    state = primary_state(job)
    pending = state.upper() in {"PD", "PENDING"}
    finished = state.upper() in FINISHED_STATES
    # Elapsed time, progress and time left describe jobs that are still on a node.
    elapsed = (
        now - start if start is not None and start <= now and not finished else None
    )

    if elapsed is None:
        left = None
    elif end is not None:
        left = max(end - now, 0)
    elif limit is not None and elapsed is not None:
        left = max(limit - elapsed, 0)
    else:
        left = None

    time_left = format_duration(math.inf if limit == math.inf else left)
    progress = ""
    if elapsed is not None and limit not in (None, math.inf):
        progress = f"{progress_bar(elapsed / limit)} {time_left}"
    elif elapsed is not None and limit == math.inf:
        progress = "no limit"

    raw_id = unwrap_slurm_value(job.get("job_id"))
    sprio = (priorities or {}).get(raw_id)
    if sprio:
        priority = sprio["priority"]
    else:
        priority = unwrap_slurm_value(job.get("priority"))
        if not isinstance(priority, (int, float)) or isinstance(priority, bool):
            priority = None
    cpus = unwrap_slurm_value(job.get("cpus"))

    raw_reason = format_value(job.get("state_reason"))
    if pending:
        reason, severity = describe_reason(raw_reason, job.get("dependency"))
    else:
        reason, severity = format_value(job.get("state_reason")), None
        if reason == "None":
            reason = ""
    state_label, state_severity = FINISHED_STATES.get(
        state.upper(), (state.lower().replace("_", " "), None)
    )
    memory = tres_memory_mb(job.get("tres_alloc_str"))
    if memory is None:
        memory = tres_memory_mb(job.get("tres_req_str"))
    fraction = elapsed / limit if elapsed is not None and limit else None

    priority_text = "" if priority is None else str(int(priority))
    if sprio and format_factors(sprio["factors"]):
        priority_text += f" ({format_factors(sprio['factors'])})"

    normalized = {
        "job_id": format_job_id(job),
        "name": format_value(job.get("name")),
        "user": format_value(job.get("user_name")),
        "cwd": strip_prefix(job.get("current_working_directory"), prefixes),
        "_output": output_path(job, "standard_output"),
        "_errors": output_path(job, "standard_error"),
        "cpus": format_value(job.get("cpus")),
        "mem": format_memory(memory),
        "gpus": format_gpu_requests(job, gpu_types),
        "state": state,
        "state_label": state_label,
        "nodes": format_value(job.get("nodes")),
        "partition": format_value(job.get("partition")),
        "elapsed": format_duration(elapsed),
        "progress": progress,
        "time_left": time_left,
        "end_time": format_when(end, now) if elapsed is not None else "",
        "time_limit": format_duration(limit),
        "submitted": format_when(submit, now),
        "waiting": format_duration(now - submit) if submit and pending else "",
        "est_start": f"~{format_when(start, now)}"
        if pending and start and start > now
        else "",
        "est_start_at": format_when(start, now) if start and start > now else "",
        "_est_start_in": format_until(start, now) if pending else "",
        "_ends_in": format_until(end, now) if elapsed is not None else "",
        "_limit_seconds": limit,
        "priority": priority_text,
        "reason": reason,
        "exit": format_exit_code(job.get("exit_code")) if finished else "",
        "ran": format_duration(end - start) if finished and start and end else "",
        "_ran": end - start if finished and start and end else None,
        "ended": format_when(end, now) if finished else "",
        "_routine": pending and raw_reason in ROUTINE_REASONS,
        "_hint": REASON_HINTS.get(raw_reason, "") if pending else "",
        "_elapsed": elapsed,
        "_job_id": sort_number(job.get("job_id")),
        "_end_time": sort_number(job.get("end_time")),
        "_ended": -end if end is not None else float("inf"),
        "_submit_time": sort_number(job.get("submit_time")),
        "_priority": -priority if priority is not None else float("inf"),
        "_cpus": cpus if isinstance(cpus, int) and not isinstance(cpus, bool) else 0,
        "_gpus": gpu_count(job.get("tres_alloc_str")),
        "_mem": memory or 0,
        "_fraction": fraction,
        "_severity": severity if pending else state_severity,
        "_array_id": array_task_key(job),
        "_array_job": array_job_id(job),
        "_where": "",
        "_raw": job,
    }
    normalized["resources"] = format_resources(
        normalized["cpus"], normalized["mem"], normalized["gpus"]
    )
    normalized["outcome"] = outcome_text(normalized) if finished else ""
    normalized["note"], outcome_hint = (
        explain_outcome(normalized) if finished else ("", "")
    )
    if finished:
        normalized["_hint"] = outcome_hint
    if "{id}" in normalized["_hint"]:
        normalized["_hint"] = normalized["_hint"].format(id=normalized["job_id"])
    category = classify_job(normalized)
    normalized["glyph"], normalized["_glyph_style"] = status_glyph(
        category, normalized["_severity"]
    )
    if category == "RUNNING" and (fraction or 0) >= NEAR_LIMIT:
        normalized["_glyph_style"] = "warn"
    if category == "OTHER" and not finished:
        normalized["outcome"] = state_label
    return normalized


def output_path(job, key):
    """A job's output or error file, with Slurm's filename patterns filled in.

    squeue usually reports the expanded path, but not always (`out.%J`).
    """
    path = format_value(job.get(key))
    if "%" not in path:
        return path
    array_id = unwrap_slurm_value(job.get("array_job_id"))
    task_id = unwrap_slurm_value(job.get("array_task_id"))
    # The first node of a list such as `gpu[01-02],cpu03`.
    first = re.match(
        r"([^\[,]*)(?:\[(\d+))?",
        format_value(job.get("nodes") or job.get("batch_host")),
    )
    values = {
        "j": format_value(job.get("job_id")),
        "J": format_value(job.get("job_id")),
        "A": format_value(array_id) if array_id else format_value(job.get("job_id")),
        "a": format_value(task_id) if task_id not in (None, "") else "4294967294",
        "x": format_value(job.get("name")),
        "u": format_value(job.get("user_name")),
        "N": first.group(1) + (first.group(2) or ""),
        "n": "0",
        "t": "0",
        "%": "%",
    }

    def fill(match):
        value = values.get(match.group(2))
        if value is None:
            return match.group(0)
        width = match.group(1)
        return value.zfill(int(width)) if width and value.isdigit() else value

    return re.sub(r"%(\d*)([AaJjNntux%])", fill, path)


def array_job_id(job):
    """The array job ID of a task or of a pending array record, else None."""
    array_id = unwrap_slurm_value(job.get("array_job_id"))
    if isinstance(array_id, int) and 0 < array_id < SLURM_NO_VAL:
        return array_id
    return None


def array_task_key(job):
    """(array job ID, task ID) of a single array task, else None."""
    array_id = unwrap_slurm_value(job.get("array_job_id"))
    task_id = unwrap_slurm_value(job.get("array_task_id"))
    if (
        isinstance(array_id, int)
        and 0 < array_id < SLURM_NO_VAL
        and isinstance(task_id, int)
        and 0 <= task_id < SLURM_NO_VAL
        and not format_value(job.get("array_task_string"))
    ):
        return array_id, task_id
    return None


def task_ranges(ids):
    """[1, 2, 3, 7] -> `1-3,7`."""
    ids = sorted(set(ids))
    parts = []
    start = previous = ids[0]
    for task in [*ids[1:], None]:
        if task is not None and task == previous + 1:
            previous = task
            continue
        parts.append(str(start) if start == previous else f"{start}-{previous}")
        if task is not None:
            start = previous = task
    return ",".join(parts)


SEVERITY_ORDER = {"error": 3, "warn": 2, "ok": 1, None: 0}


def group_tasks(name, jobs, expanded=()):
    """A category's rows, with the rows of one array job kept together where
    its first row sorts, and its tasks folded into one row.

    Arrays whose ID is in `expanded` keep one row per task; the first of them
    is marked ▾. A folded row is marked ▸, has `_tasks` (its jobs, in display
    order) and sums or summarizes their fields. Other rows of the array (the
    record of tasks not started yet, the array job itself) follow its tasks.
    """
    members = {}
    for job in jobs:
        if job.get("_array_job") is not None:
            members.setdefault(job["_array_job"], []).append(job)
    rows = []
    placed = set()
    for job in jobs:
        array = job.get("_array_job")
        if array is None:
            rows.append(job)
            continue
        if array in placed:
            continue
        placed.add(array)
        group = members[array]
        if len(group) < 2:
            rows.extend(group)
            continue
        tasks = [row for row in group if row.get("_array_id")]
        rest = [row for row in group if not row.get("_array_id")]
        if len(tasks) < 2:
            rows.extend(tasks + rest)
        elif array in expanded:
            rows.extend(
                {**row, "_marker": "▾ " if index == 0 else "  "}
                for index, row in enumerate(tasks + rest)
            )
        else:
            rows.append(fold_tasks(name, array, tasks))
            rows.extend(rest)
    return rows


def fold_tasks(name, array_id, tasks):
    """One row standing for several tasks of an array job."""
    first = tasks[0]
    row = dict(first)
    count = len(tasks)
    row["job_id"] = f"{array_id}_[{task_ranges(t['_array_id'][1] for t in tasks)}]"
    row["_marker"] = "▸ "
    row["resources"] = f"{first['resources']} ×{count}".strip()
    row["_cpus"] = sum(task["_cpus"] for task in tasks)
    row["_mem"] = sum(task["_mem"] for task in tasks)
    row["_gpus"] = sum(task["_gpus"] for task in tasks)
    row["nodes"] = ",".join(dict.fromkeys(t["nodes"] for t in tasks if t["nodes"]))
    fractions = [t["_fraction"] for t in tasks if t["_fraction"] is not None]
    if fractions and name == "RUNNING":
        # The task nearest its limit speaks for the row.
        nearest = max(tasks, key=lambda t: t["_fraction"] or 0)
        row["progress"] = nearest["progress"]
        row["end_time"] = nearest["end_time"]
        row["_fraction"] = max(fractions)
        row["_glyph_style"] = nearest["_glyph_style"]
    if name == "OTHER":
        counts = {}
        for task in tasks:
            counts[task["state_label"]] = counts.get(task["state_label"], 0) + 1
        row["outcome"] = ", ".join(f"{n} {label}" for label, n in counts.items())
        # The longest task speaks for how long the array's tasks ran.
        ran = [task["_ran"] for task in tasks if task.get("_ran") is not None]
        row["ran"] = f"≤{format_duration(max(ran))}" if ran else ""
        row["note"] = ""
    row["_severity"] = max(
        (task["_severity"] for task in tasks), key=SEVERITY_ORDER.__getitem__
    )
    row["_tasks"] = tasks
    row["_array_id"] = None
    return row


def group_users(name, rows, expanded=(), first=()):
    """Rows of all users' jobs, one ▸ row per user; `expanded` users show
    their jobs under it. Users in `first` (yours) come first, the rest by
    the CPUs they use or ask for, then by name.

    A user's row has `_group` (the user) and `_members` (their rows).
    """
    by_user = {}
    for row in rows:
        by_user.setdefault(row["user"], []).append(row)

    def weight(user):
        members = by_user[user]
        return (user not in first, -sum(r["_cpus"] for r in members), user)

    grouped = []
    for user in sorted(by_user, key=weight):
        members = by_user[user]
        jobs = sum(len(r.get("_tasks", ())) or 1 for r in members)
        gpus = sum(r["_gpus"] for r in members)
        resources = format_resources(
            sum(r["_cpus"] for r in members),
            format_memory(memory)
            if (memory := sum(r["_mem"] for r in members))
            else "",
            plural(gpus, "GPU") if gpus else "",
        )
        group = {
            "job_id": "",
            "name": user or "?",
            "user": user,
            "title": "",
            "resources": resources,
            "glyph": "",
            "_glyph_style": "",
            "_marker": "▾ " if user in expanded else "▸ ",
            "_summary": plural(jobs, "job"),
            "_group": user,
            "_members": members,
            "_severity": max(
                (r["_severity"] for r in members), key=SEVERITY_ORDER.__getitem__
            ),
            "_cpus": sum(r["_cpus"] for r in members),
            "_mem": sum(r["_mem"] for r in members),
            "_gpus": gpus,
        }
        if name == "OTHER":
            words = {"ok": "completed", "error": "failed", "warn": "cancelled"}
            counts = {}
            for r in members:
                for task in r.get("_tasks") or [r]:
                    word = words.get(task["_severity"], "other")
                    counts[word] = counts.get(word, 0) + 1
            group["outcome"] = ", ".join(
                f"{counts[word]} {word}"
                for word in ("completed", "failed", "cancelled", "other")
                if word in counts
            )
            group["resources"] = ""
            # The summary is news only on the jobs themselves.
            group["_severity"] = None
        grouped.append(group)
        if user in expanded:
            grouped.extend({**r, "_indent": True} for r in members)
    return grouped


def job_key(job):
    """A job's identity across refreshes."""
    return job["job_id"]


def job_changes(old_jobs, new_jobs):
    """What happened between two refreshes: [(job, event, severity)].

    Events are "started" and "ended"; jobs seen for the first time count when
    they are already running or finished (they changed between refreshes).
    """
    before = {job_key(job): classify_job(job) for job in old_jobs}
    changes = []
    for job in new_jobs:
        now, was = classify_job(job), before.get(job_key(job))
        if now == was or (was is None and now == "PENDING"):
            continue
        if now == "RUNNING":
            changes.append((job, "started", None))
        elif now == "OTHER" and job["state"].upper() in FINISHED_STATES:
            changes.append((job, "ended", job["_severity"]))
    return changes


def describe_change(job, event):
    """`1234 md-run started on gpu07`, `1234 md-run failed (exit 1)`."""
    name = f"{job['job_id']} {job['name']}".strip()
    if event == "started":
        return f"{name} started" + (f" on {job['nodes']}" if job["nodes"] else "")
    detail = f" (exit {job['exit']})" if job["exit"] not in ("", "0") else ""
    return f"{name} {job['state_label']}{detail}"


def split_sections(stdout):
    """Split the script output into (home directories, {section: text}, JSON).

    Anything a login profile prints before the first marker is dropped.
    Everything after the squeue marker is its JSON. Without markers, the homes
    are unknown and the whole output is treated as JSON.
    """
    lines = stdout.splitlines(keepends=True)
    homes = []
    sections = {}
    current = None
    last = None
    for index, line in enumerate(lines):
        if line.startswith(REMOTE_HOME_MARKER):
            home = line.removeprefix(REMOTE_HOME_MARKER).rstrip("\r\n")
            if home and home not in homes:
                homes.append(home)
            current, last = None, index
        elif line.startswith(SECTION_MARKER):
            name = line.removeprefix(SECTION_MARKER).strip()
            if name == "squeue":
                return homes, sections, "".join(lines[index + 1 :])
            current, last = name, index
            sections[current] = ""
        elif current is not None:
            sections[current] += line
    if last is None:
        return [], {}, stdout
    return homes, sections, "".join(lines[last + 1 :]) if current is None else ""


def fetch_snapshot(show_all=False, username=None, host=None, config=None, now=None):
    """Fetch and normalize all jobs plus fair share and priority data.

    Returns a dict with `jobs`, `shares` and per-tool `problems`.
    """
    now = time.time() if now is None else now
    idle_wanted = bool((config or {}).get("idle_nodes"))
    stdout = run_squeue(
        show_all=show_all, username=username, host=host, idle=idle_wanted
    )
    homes, sections, stdout = split_sections(stdout)
    if not homes and not host:
        homes = local_homes()
    jobs = parse_squeue_json(stdout)
    priorities, sprio_problem = parse_sprio(sections.get("sprio"))
    shares, sshare_problem = parse_sshare(sections.get("sshare"))
    prefixes = path_prefixes(config, homes)
    gpu_types = (config or {}).get("gpu_types", ())
    jobs = [normalize_job(job, prefixes, now, priorities, gpu_types) for job in jobs]
    resolve_dependencies(jobs, now)
    idle, sinfo_problem = (
        parse_sinfo(sections.get("sinfo")) if idle_wanted else ({}, None)
    )
    for job in jobs:
        if classify_job(job) == "PENDING":
            # Free capacity only matters to jobs waiting their turn, not to
            # held ones or ones waiting for other jobs.
            waiting = job.get("_routine")
            job["_idle"] = describe_idle(idle, job_partitions(job)) if waiting else ""
            job["_fairshare"] = job_fairshare(job, shares)
    return {
        "jobs": jobs,
        "shares": shares,
        "idle": idle,
        "problems": {
            "sshare": sshare_problem,
            "sprio": sprio_problem,
            "sinfo": sinfo_problem,
        },
    }


def parse_sinfo(text):
    """`sinfo -h -o SINFO_FORMAT` rows -> ({partition: counts}, problem)."""
    idle = {}
    for line in (text or "").splitlines():
        parts = line.strip().split("|")
        if len(parts) != 3:
            continue
        try:
            _a, nodes_idle, _o, nodes_total = map(int, parts[1].split("/"))
            _a, cpus_idle, _o, _t = map(int, parts[2].split("/"))
        except ValueError:
            continue
        idle[parts[0]] = {
            "nodes": nodes_idle,
            "total": nodes_total,
            "cpus": cpus_idle,
        }
    return idle, None if idle else first_line(text)


def job_partitions(job):
    """The partitions a job may run in (a pending job can list several)."""
    return [name for name in job.get("partition", "").split(",") if name]


def describe_idle(idle, partitions):
    """`gpu: 340 CPUs free, 2 of 40 nodes idle`, for each partition known to
    sinfo. Free CPUs first: a small job fits on a partly used node."""
    parts = []
    for name in partitions:
        counts = idle.get(name)
        if counts is None:
            continue
        parts.append(
            f"{name}: {plural(counts['cpus'], 'CPU')} free, "
            f"{counts['nodes']} of {counts['total']} nodes idle"
        )
    return "; ".join(parts)


def build_sacct_script(hours, username=None):
    """Script: home markers, then sacct for jobs that finished in the last
    `hours` (yours, or `username`'s)."""
    command = [
        "sacct",
        "-X",
        "-n",
        "-P",
        "-S",
        f"now-{int(hours)}hours",
        "-E",
        "now",
        "-s",
        SACCT_STATES,
        "-o",
        ",".join(SACCT_FIELDS),
    ]
    if username:
        command += ["-u", username]
    home = shlex.quote(REMOTE_HOME_MARKER)
    return "; ".join(
        [
            (
                f"printf '%s%s\\n%s%s\\n' {home} \"$HOME\" {home} "
                '"$(cd 2>/dev/null && pwd -P)"'
            ),
            optional_section("sacct", shlex.join(command)),
        ]
    )


def fetch_history(hours, username=None, host=None, config=None, now=None):
    """Jobs that finished in the last `hours`, from sacct, normalized.

    Returns (jobs, problem); one extra command, made once, on request.
    """
    now = time.time() if now is None else now
    script = build_sacct_script(hours, username)
    if host:
        cmdline = ["ssh", host, shlex.join(["sh", "-lc", script])]
    else:
        cmdline = ["sh", "-c", script]
    description = "sacct" + (f" on {host}" if host else "")
    homes, sections, _rest = split_sections(
        run_command(cmdline, description, "read the job history")
    )
    if not homes and not host:
        homes = local_homes()
    raw, problem = parse_sacct(sections.get("sacct"))
    prefixes = path_prefixes(config, homes)
    gpu_types = (config or {}).get("gpu_types", ())
    return [normalize_job(job, prefixes, now, None, gpu_types) for job in raw], problem


def sacct_time(text):
    """`2026-11-28T15:00:00` -> epoch seconds; None for Unknown or None."""
    try:
        return int(datetime.fromisoformat(text.strip()).timestamp())
    except ValueError:
        return None


def parse_sacct(text):
    """`sacct -P` rows (SACCT_FIELDS) -> (squeue-like job dicts, problem)."""
    jobs = []
    for line in (text or "").splitlines():
        parts = line.rstrip("\n").split("|")
        if len(parts) != len(SACCT_FIELDS) or not parts[0].isdigit():
            continue
        row = dict(zip(SACCT_FIELDS, parts, strict=True))
        end = sacct_time(row["End"])
        if end is None:
            continue
        job = {
            "job_id": int(row["JobIDRaw"]),
            "name": row["JobName"],
            "job_state": [row["State"].split()[0] if row["State"] else ""],
            "user_name": row["User"],
            "current_working_directory": row["WorkDir"],
            "partition": row["Partition"],
            "nodes": "" if row["NodeList"] == "None assigned" else row["NodeList"],
            "start_time": sacct_time(row["Start"]),
            "end_time": end,
        }
        array = re.fullmatch(r"(\d+)_(\d+)", row["JobID"])
        if array:
            job["array_job_id"] = int(array.group(1))
            job["array_task_id"] = int(array.group(2))
        het = re.fullmatch(r"(\d+)\+(\d+)", row["JobID"])
        if het:
            job["het_job_id"] = int(het.group(1))
            job["het_job_offset"] = int(het.group(2))
        if row["Timelimit"] == "UNLIMITED":
            job["time_limit"] = {"set": True, "infinite": True, "number": 0}
        elif (seconds := cpu_seconds(row["Timelimit"])) is not None:
            job["time_limit"] = int(seconds // 60)
        if row["AllocCPUS"].isdigit():
            job["cpus"] = int(row["AllocCPUS"])
        memory = re.sub(r"[cn]$", "", row["ReqMem"])
        if memory:
            job["tres_req_str"] = f"mem={memory}"
        code, _sep, signal = row["ExitCode"].partition(":")
        if code.isdigit():
            job["exit_code"] = {
                "return_code": int(code),
                "signal": {"id": int(signal)} if signal.isdigit() else {},
            }
        jobs.append(job)
    return jobs, None if jobs else first_line(text)


def classify_job(job):
    """Return display category for a job."""
    state = job["state"].upper()

    if state in {"R", "RUNNING"}:
        return "RUNNING"

    if state in {"PD", "PENDING"}:
        return "PENDING"

    return "OTHER"


def sort_jobs(name, jobs):
    """Sort a category's jobs by its sort keys (stable for ties)."""
    keys = CATEGORIES[name]["sort"]
    return sorted(
        jobs, key=lambda job: tuple(job.get(key, float("inf")) for key in keys)
    )


def truncate_right(text, max_width):
    """Right-truncate text to max_width characters, keeping the start."""
    if len(text) <= max_width:
        return text

    return text[: max_width - 1] + "…"


# Columns cut to a maximum width, and how: paths keep their end, job IDs their
# closing bracket, the rest their start.
CAPPED = {
    "job_id": MAX_JOB_ID_WIDTH,
    "cwd": MAX_CWD_WIDTH,
    "title": MAX_TITLE_WIDTH,
    "reason": MAX_REASON_WIDTH,
    "note": MAX_NOTE_WIDTH,
}


def truncate_job_id(text, max_width):
    """Shorten an array task list, keeping the job ID and closing bracket."""
    if len(text) <= max_width:
        return text
    if text.endswith("]") and "[" in text:
        return text[: max_width - 2] + "…]"
    return truncate_right(text, max_width)


CUT = {"cwd": truncate_left, "job_id": truncate_job_id}


def category_fields(name, columns=()):
    """A category's columns; those in OPTIONAL_COLUMNS only when in `columns`."""
    return [
        (key, header)
        for key, header in CATEGORIES[name]["fields"]
        if key not in OPTIONAL_COLUMNS or key in columns
    ]


def category_rows(
    name, jobs, expanded=(), summaries=None, by_user=False, users=(), first=()
):
    """A category's rows in display order: sorted, arrays folded, each array
    row with its progress (`summaries`, from array_summaries), and with
    `by_user` one row per user (`users` expanded, `first` on top)."""
    rows = group_tasks(name, sort_jobs(name, jobs), expanded)
    summaries = summaries or {}
    rows = [
        {**row, "_summary": summaries[row["_array_job"]]}
        if row.get("_array_job") in summaries
        else row
        for row in rows
    ]
    if by_user:
        rows = group_users(name, rows, users, first)
    return rows


def title_parts(job):
    """The Name cell as (text, style name) parts: marker, name, then faint
    context (the end of the path for repeated names, array progress)."""
    parts = []
    if job.get("_indent"):
        parts.append(("  ", ""))
    if job.get("_marker"):
        parts.append((job["_marker"], "muted"))
    parts.append(
        (
            truncate_right(job.get("name", ""), MAX_NAME_WIDTH),
            "bold" if job.get("_group") else "",
        )
    )
    for extra in (job.get("_where"), job.get("_summary")):
        if extra:
            parts.append(("  " + extra, "muted"))
    return parts


def cell(job, key, widths):
    """One plain-text table cell, cut to its width if it has one."""
    if key == "title":
        value = "".join(text for text, _style in title_parts(job))
    else:
        value = job.get(key, "")
    if key in widths and len(value) > widths[key]:
        return CUT.get(key, truncate_right)(value, widths[key])
    return value


def near_limit(job):
    return (job.get("_fraction") or 0) >= NEAR_LIMIT


def cell_style(job, key):
    """Style for a cell: what needs attention stands out, routine fades."""
    severity = job.get("_severity")
    if key == "glyph":
        return resolve_style(job.get("_glyph_style", ""))
    if key == "reason":
        if severity == "error":
            return resolve_style("error")
        return resolve_style("muted") if job.get("_routine") else ""
    if key == "outcome" and severity == "error":
        return resolve_style("error")
    if key in ("job_id", "waiting", "time_limit"):
        return resolve_style("muted")
    if key == "time_left" and near_limit(job):
        return "bold"
    return ""


def job_cell(job, key, widths=CAPPED):
    """A styled cell for the interactive view."""
    if key == "progress" and job.get(key, "").startswith((BAR_DONE, BAR_LEFT)):
        # Done part in color (yellow near the limit), the rest faint, then
        # the time left, bold near the limit.
        bar, left = job[key][:PROGRESS_WIDTH], job[key][PROGRESS_WIDTH:]
        filled = bar.count(BAR_DONE)
        return Text.assemble(
            (bar[:filled], resolve_style("warn" if near_limit(job) else "running")),
            (bar[filled:], resolve_style("muted")),
            (left, "bold" if near_limit(job) else ""),
            no_wrap=True,
        )
    if key == "title":
        text = Text.assemble(
            *((part, resolve_style(style)) for part, style in title_parts(job)),
            no_wrap=True,
        )
        if key in widths and len(text) > widths[key]:
            text.truncate(widths[key], overflow="ellipsis")
        return text
    return Text(
        cell(job, key, widths),
        style=cell_style(job, key),
        justify="right" if key in RIGHT_ALIGNED else "left",
        no_wrap=True,
    )


def fit_widths(fields, jobs):
    """Each column's width: its widest cell or header, CAPPED columns cut."""
    return {
        key: max([len(header)] + [len(cell(job, key, CAPPED)) for job in jobs])
        for key, header in fields
    }


def shown_fields(fields, rows):
    """The fields without columns that are empty in every row."""
    return [
        (key, header)
        for key, header in fields
        if key in ALWAYS_SHOWN or any(row.get(key) for row in rows)
    ]


def table_width(widths, keys):
    """Width of a table: each column plus one cell of padding on either side."""
    return sum(widths[key] + 2 for key in keys)


def fit_columns(fields, widths, available):
    """Make a table fit `available` cells: shrink paths and node lists, drop the
    least useful columns, shrink names and reasons, then drop more (DROP_ORDER).

    Returns (fields, widths, headers of dropped columns). A table that still
    does not fit scrolls sideways.
    """
    widths = dict(widths)
    keys = [key for key, _header in fields]
    dropped = []

    def excess():
        return table_width(widths, keys) - available

    def shrink(names):
        for key in names:
            if key in keys and excess() > 0:
                widths[key] = max(SHRINK_TO[key], widths[key] - excess())

    def drop(below):
        for key in sorted(
            (k for k in keys if DROP_ORDER.get(k, math.inf) < below),
            key=DROP_ORDER.__getitem__,
        ):
            if excess() <= 0:
                return
            keys.remove(key)
            dropped.append(key)

    shrink(("cwd", "nodes"))
    drop(30)
    shrink(("title",))
    drop(50)
    shrink(("reason",))
    drop(math.inf)
    headers = dict(fields)
    return (
        [(key, headers[key]) for key in keys],
        {key: widths[key] for key in keys},
        [headers[key] for key in dropped],
    )


def align_widths(tables):
    """Column widths for tables shown one above the other, lined up.

    `tables` maps a name to (fields, rows). A column at the same position, with
    the same columns before it, in several tables gets one width in all of
    them. Returns {name: {key: width}}.
    """
    keys = {
        name: [key for key, _header in fields] for name, (fields, _) in tables.items()
    }
    group_of = {}
    for name in tables:
        for position, key in enumerate(keys[name]):
            prefix = keys[name][: position + 1]
            members = frozenset(
                other for other in tables if keys[other][: position + 1] == prefix
            )
            group_of[name, key] = (position, members) if len(members) > 1 else name
    width = {}
    for name, (fields, rows) in tables.items():
        for key, natural in fit_widths(fields, rows).items():
            group = (group_of[name, key], key)
            width[group] = max(width.get(group, 0), natural)
    return {
        name: {key: width[group_of[name, key], key] for key in keys[name]}
        for name in tables
    }


def category_title(name, shown, total=None, note=None, width=None):
    """A section rule: `── Running · 3 ───── note ──`, `Pending · 2 of 12` when
    filtered. Without a width there is no rule to the right."""
    count = f"{shown} of {total}" if total is not None and total != shown else shown
    muted = resolve_style("muted")
    text = Text.assemble(
        ("── ", muted),
        (CATEGORIES[name]["title"], "bold"),
        (f" · {count} ", muted),
    )
    tail = Text()
    if note:
        tail.append(" ")
        tail.append_text(note)
        tail.append(" ──", style=muted)
    if width:
        room = width - len(text)
        if len(tail) > room:
            # Notes give way before the line wraps.
            tail.truncate(max(room, 0), overflow="ellipsis")
        text.append("─" * (room - len(tail)), style=muted)
    text.append_text(tail)
    return text


FAIRSHARE_MEANINGS = (
    (0.5, "good", "you have used less than your share, so your jobs rank higher"),
    (0.2, "fair", "you have used about your share"),
    (0.0, "low", "you have used more than your share, so your jobs rank lower"),
)


def fairshare_verdict(value):
    """A word and what it means for a fair share value."""
    for threshold, word, meaning in FAIRSHARE_MEANINGS:
        if value >= threshold:
            return word, meaning
    return FAIRSHARE_MEANINGS[-1][1:]


def fairshare_note(shares):
    """`fair share low`, per account if there are several. What it means is
    in each pending job's details (`_fairshare`)."""
    if not shares:
        return None
    muted = resolve_style("muted")
    text = Text("fair share", style=muted)
    for index, row in enumerate(shares):
        word, _meaning = fairshare_verdict(row["fairshare"])
        text.append("," if index else "", style=muted)
        if len(shares) > 1:
            text.append(f" {row['account']}", style=muted)
        text.append(f" {word}", style="bold")
    return text


def job_fairshare(job, shares):
    """`low: you have used more than your share, so your jobs rank lower` for
    a pending job of a user whose sshare row we have, else ""."""
    account = (job.get("_raw") or {}).get("account")
    rows = [row for row in shares if row["user"] == job["user"]]
    # The job's own account if sshare lists it, else the user's first.
    rows.sort(key=lambda row: row["account"] != account)
    if not rows:
        return ""
    word, meaning = fairshare_verdict(rows[0]["fairshare"])
    return f"{word}: {meaning}"


def plural(count, noun):
    """`1 GPU`, `2 GPUs`."""
    return f"{count} {noun}{'' if count == 1 else 's'}"


def scope_label(show_all=False, username=None):
    if username:
        return f"{username}'s jobs"
    return "all users" if show_all else "my jobs"


def render_header(grouped, host, scope, shares=None):
    """`marc3a · my jobs   using 80 CPUs · 144G · 1 GPU · fair share low`."""
    muted = resolve_style("muted")
    line = Text.assemble((host or "local", "bold"), (f" · {scope}", muted))
    running = grouped["RUNNING"]
    if running:
        totals = [plural(sum(job["_cpus"] for job in running), "CPU")]
        memory = sum(job["_mem"] for job in running)
        if memory:
            totals.append(format_memory(memory))
        gpus = sum(job["_gpus"] for job in running)
        if gpus:
            totals.append(plural(gpus, "GPU"))
        line.append("   using ", style=muted)
        line.append(" · ".join(totals))
    elif any(grouped.values()):
        line.append("   nothing running", style=muted)
    fairshare = fairshare_note(shares)
    if fairshare is not None:
        line.append(" · " if running else "   ", style=muted)
        line.append_text(fairshare)
    return line


def render_status(fetched_at, seconds_left=None, busy=False, failed=False):
    """`updated 16:02 · next in 0:42`; `updating…` during a fetch."""
    muted = resolve_style("muted")
    text = Text()
    if fetched_at is not None:
        text.append(f"updated {datetime.fromtimestamp(fetched_at):%H:%M}", style=muted)
    if failed:
        text.append(" · " if text else "")
        text.append("update failed", style=resolve_style("error"))
    if busy:
        text.append(" · " if text else "")
        text.append("updating…", style=muted)
    elif seconds_left is not None:
        text.append(" · " if text else "")
        minutes, seconds = divmod(max(int(seconds_left), 0), 60)
        text.append(f"next in {minutes}:{seconds:02d}", style=muted)
    return text


# Failed jobs stay in the attention lines for this long after they end.
RECENT_FAILURE = 3600


def attention_lines(grouped, now, own=None):
    """Jobs that need the user, most urgent first: running jobs about to hit
    their time limit, pending jobs that will never start, recent failures.
    One line per kind: a job by name, or several by count.

    `own` limits them to these users' jobs.
    """
    muted = resolve_style("muted")
    error = resolve_style("error")

    def mine(job):
        return own is None or job["user"] in own

    def ended_recently(job):
        ended = -job["_ended"] if job["_ended"] != math.inf else None
        return ended is not None and now - ended < RECENT_FAILURE

    def names(jobs, limit=3):
        shown = ", ".join(job["name"] or job["job_id"] for job in jobs[:limit])
        return shown + (", …" if len(jobs) > limit else "")

    def one(glyph, job, *rest):
        return Text.assemble(
            glyph,
            " ",
            (job["name"] or job["job_id"], "bold"),
            (f" {job['job_id']}" if job["name"] else "", muted),
            " ",
            *rest,
        )

    def several(glyph, jobs, words):
        return Text.assemble(
            glyph,
            " ",
            (f"{len(jobs)} jobs", "bold"),
            f" {words}: ",
            (names(jobs), muted),
        )

    warn = ("●", resolve_style("warn"))
    cross = ("✗", error)
    lines = []
    closing = [j for j in grouped["RUNNING"] if near_limit(j) and mine(j)]
    if len(closing) == 1:
        job = closing[0]
        lines.append(
            one(
                warn,
                job,
                f"reaches its time limit {job['end_time']} ({job['time_left']} left)",
            )
        )
    elif closing:
        lines.append(several(warn, closing, "are about to reach their time limit"))
    blocked = [j for j in grouped["PENDING"] if j["_severity"] == "error" and mine(j)]
    if len(blocked) == 1:
        lines.append(one(cross, blocked[0], (blocked[0]["reason"], error)))
    elif blocked:
        lines.append(several(cross, blocked, "will never start"))
    failed = [
        j
        for j in grouped["OTHER"]
        if j["_severity"] == "error" and ended_recently(j) and mine(j)
    ]
    if len(failed) == 1:
        job = failed[0]
        note = f" · {job['note']}" if job["note"] else ""
        lines.append(one(cross, job, (job["outcome"], error), note))
    elif failed:
        lines.append(several(cross, failed, "failed in the last hour"))
    return lines


def render_notes(grouped, snapshot):
    """Notes about data that could not be read."""
    problems = snapshot["problems"]
    notes = []
    if problems.get("sshare") and grouped["PENDING"]:
        notes.append(f"fair share unavailable: {problems['sshare']}")
    if problems.get("sinfo"):
        notes.append(f"idle nodes unavailable: {problems['sinfo']}")
    # sprio reports an error when there is nothing pending; only then is it news.
    if problems.get("sprio") and grouped["PENDING"]:
        notes.append(f"priority factors unavailable: {problems['sprio']}")
    return [Text(note, style=resolve_style("muted")) for note in notes]


def group_jobs(jobs):
    """Jobs by category, in CATEGORIES order."""
    grouped = {category: [] for category in CATEGORIES}
    for job in jobs:
        grouped[classify_job(job)].append(job)
    return grouped


def parse_columns(_ctx, _param, value):
    """`cwd,nodes` -> ("cwd", "nodes"); `all` selects every optional column."""
    if not value:
        return ()
    names = [name.strip() for name in value.split(",") if name.strip()]
    if "all" in names:
        return tuple(OPTIONAL_COLUMNS)
    unknown = [name for name in names if name not in OPTIONAL_COLUMNS]
    if unknown:
        raise click.BadParameter(
            f"unknown {', '.join(unknown)} (choose from "
            f"{', '.join(OPTIONAL_COLUMNS)}, or all)"
        )
    return tuple(names)


@click.command()
@click.version_option(package_name="sjobs")
@click.option(
    "--all",
    "show_all",
    is_flag=True,
    help="Show jobs for all users instead of only your own jobs.",
)
@click.option(
    "--user",
    "username",
    metavar="USERNAME",
    help="Show jobs for the specified user.",
)
@click.option(
    "--host",
    "-H",
    "host",
    metavar="HOST",
    help=f"SSH host to run squeue on (overrides {HOST_ENV_VAR} and the config file).",
)
@click.option(
    "--columns",
    "-c",
    "extra_columns",
    metavar="LIST",
    callback=parse_columns,
    help=f"Extra columns, comma-separated: {', '.join(OPTIONAL_COLUMNS)}, or all.",
)
@click.option(
    "--interval",
    type=click.IntRange(min=MIN_INTERVAL),
    default=DEFAULT_INTERVAL,
    show_default=True,
    metavar="SECONDS",
    help=f"Seconds between refreshes (at least {MIN_INTERVAL}, to keep load on "
    "the Slurm controller low).",
)
def main(show_all, username, host, extra_columns, interval):
    """Watch your Slurm jobs, why pending jobs wait, and your fair share.

    Press ? in the view for the keys and what the numbers mean.
    """
    config = load_config()
    host = resolve_host(host, config)
    columns = tuple(
        key
        for key in OPTIONAL_COLUMNS
        if key in extra_columns or key in config.get("columns", [])
    )
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        raise click.ClickException("sjobs is interactive and needs a terminal.")

    from .tui import run_tui

    run_tui(
        show_all=show_all,
        username=username,
        host=host,
        config=config,
        interval=interval,
        columns=columns,
    )


if __name__ == "__main__":
    main()
