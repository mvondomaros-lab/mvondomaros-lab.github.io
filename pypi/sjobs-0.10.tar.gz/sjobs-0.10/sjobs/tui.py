"""The sjobs view: job tables as a Textual app that refreshes itself.

Slurm access goes through `sjobs.fetch_snapshot`, so every refresh still makes
one process (or SSH connection) and one squeue call. Cancelling a job and
reading its log are extra calls, made only when the user asks.
"""

import os
import re
import select
import sys
import time
from typing import ClassVar

import click
from rich.console import Group
from rich.padding import Padding
from rich.segment import Segment, Segments
from rich.style import Style
from rich.table import Table
from rich.terminal_theme import TerminalTheme
from rich.text import Text
from textual import work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.color import Color
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.css.query import NoMatches
from textual.screen import ModalScreen
from textual.scrollbar import ScrollBar, ScrollBarRender
from textual.theme import Theme
from textual.widgets import (
    DataTable,
    Footer,
    Input,
    SelectionList,
    Static,
    Tab,
    Tabs,
)

from . import sjobs

# A manual refresh right after another one is ignored, to spare the controller.
MIN_MANUAL_REFRESH = 5
LOG_LINES = 200
# Finished jobs kept after squeue forgets them, at most.
HISTORY_LIMIT = 1000
# Rows of jobs that just started or ended stand out for this long.
CHANGED_SECONDS = 15
# The details pane sits beside the tables in windows this wide, below them
# in narrower ones, and covers them in windows shorter than this.
PREVIEW_MIN_WIDTH = 150
PREVIEW_WIDTH = 50
PREVIEW_MIN_HEIGHT = 20
FILTER_KEYS = ("job_id", "name", "user", "cwd", "reason", "partition", "state")
# The default: a theme made of the terminal's own colors.
AUTO_THEME = "auto"
TERMINAL_THEME = "terminal"


COLOR_REPORT_RE = re.compile(
    rb"\x1b\](10|11|4;(\d+));rgb:([0-9a-f]+)/([0-9a-f]+)/([0-9a-f]+)", re.IGNORECASE
)
# Device attributes: every terminal answers, so its reply ends the color query.
ATTRIBUTES_REPLY_RE = re.compile(rb"\x1b\[\?[\d;]*c")


def parse_color_reports(data):
    """Terminal color reports -> {"foreground", "background", "palette"}.

    Colors are `#rrggbb`; palette entries the terminal did not report are None.
    """
    colors = {"foreground": None, "background": None, "palette": [None] * 16}
    for match in COLOR_REPORT_RE.finditer(data):
        code, index, *channels = match.groups()
        value = "#" + "".join(
            f"{round(int(part, 16) / (16 ** len(part) - 1) * 255):02x}"
            for part in channels
        )
        if code == b"10":
            colors["foreground"] = value
        elif code == b"11":
            colors["background"] = value
        elif int(index) < 16:
            colors["palette"][int(index)] = value
    return colors


def query_terminal_colors(timeout=0.5):
    """Ask the terminal for its colors (OSC 10, 11 and 4); None if it cannot.

    Runs before the app takes over the terminal.
    """
    try:
        import termios
        import tty
    except ImportError:
        return None
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return None

    queries = b"\x1b]10;?\x1b\\\x1b]11;?\x1b\\"
    queries += b"".join(b"\x1b]4;%d;?\x1b\\" % index for index in range(16))
    fd = sys.stdin.fileno()
    data = b""
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setcbreak(fd)
            os.write(sys.stdout.fileno(), queries + b"\x1b[c")
            deadline = time.monotonic() + timeout
            while not ATTRIBUTES_REPLY_RE.search(data):
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not select.select([fd], [], [], remaining)[0]:
                    break
                data += os.read(fd, 1024)
        finally:
            # Drop a late or partial answer so it never arrives as key presses.
            termios.tcsetattr(fd, termios.TCSAFLUSH, old)
    except (OSError, termios.error):
        return None
    return parse_color_reports(data)


def luminance(color):
    """Relative brightness of `#rrggbb`, 0 (black) to 1 (white)."""
    red, green, blue = (int(color[i : i + 2], 16) / 255 for i in (1, 3, 5))
    return 0.2126 * red + 0.7152 * green + 0.0722 * blue


def rgb(color):
    return tuple(int(color[i : i + 2], 16) for i in (1, 3, 5))


def terminal_themes(colors):
    """A Textual theme and a Rich ANSI palette made of the terminal's colors.

    Either is None when the terminal did not report enough to build it.
    """
    if not colors or not (colors["background"] and colors["foreground"]):
        return None, None
    background, foreground = colors["background"], colors["foreground"]
    palette = colors["palette"]
    defaults = ("#e06c75", "#98c379", "#d19a66", "#61afef", "#c678dd", "#56b6c2")
    red, green, yellow, blue, magenta, cyan = (
        palette[index] or default for index, default in enumerate(defaults, start=1)
    )
    theme = Theme(
        name=TERMINAL_THEME,
        dark=luminance(background) < 0.5,
        background=background,
        surface=background,
        panel=background,
        foreground=foreground,
        primary=blue,
        secondary=cyan,
        accent=magenta,
        warning=yellow,
        error=red,
        success=green,
    )
    ansi = None
    if all(palette):
        colors16 = [rgb(color) for color in palette]
        ansi = TerminalTheme(
            rgb(background), rgb(foreground), colors16[:8], colors16[8:]
        )
    return theme, ansi


# Ayu's light, mirage and dark themes (github.com/ayu-theme/ayu-colors), for
# the theme list (Ctrl+P) and `theme = "ayu-light"` in the config. Cell colors
# such as red and green still come from the terminal's palette when it reports
# one.
AYU_THEMES = (
    Theme(
        name="ayu-light",
        dark=False,
        background="#F8F9FA",
        surface="#F8F9FA",
        panel="#F8F9FA",
        foreground="#5C6166",
        primary="#399EE6",
        secondary="#4CBF99",
        accent="#FFAA33",
        warning="#F2AE49",
        error="#F07171",
        success="#86B300",
    ),
    Theme(
        name="ayu-mirage",
        dark=True,
        background="#1F2430",
        surface="#1F2430",
        panel="#1F2430",
        foreground="#CCCAC2",
        primary="#73D0FF",
        secondary="#95E6CB",
        accent="#FFCC66",
        warning="#FFCC66",
        error="#F28779",
        success="#D5FF80",
    ),
    Theme(
        name="ayu-dark",
        dark=True,
        background="#0D1017",
        surface="#0D1017",
        panel="#0D1017",
        foreground="#BFBDB6",
        primary="#59C2FF",
        secondary="#95E6CB",
        accent="#E6B450",
        warning="#E6B450",
        error="#D95757",
        success="#AAD94C",
    ),
)


def matches(job, text):
    """Whether a job contains the filter text in any filterable field."""
    text = text.lower()
    return any(text in str(job.get(key, "")).lower() for key in FILTER_KEYS)


def detail_sections(job, check=None):
    """The fields worth reading, as [(title, [(label, value)])], ordered by
    what matters for the job's situation: when a running job ends, why a
    pending job waits and what to do, why a finished job ended as it did.
    `check` adds the rows of an on-demand check (sjobs.run_check)."""
    raw = job.get("_raw") or {}

    def value(key):
        return sjobs.format_value(raw.get(key))

    category = sjobs.classify_job(job)
    nodes = value("nodes") or value("scheduled_nodes")
    errors = job["_errors"]
    if category == "RUNNING":
        ends = job["end_time"]
        if ends and job.get("_ends_in"):
            ends += f" ({job['_ends_in']})"
        used = job["elapsed"]
        if used and job["time_limit"]:
            used += f" of {job['time_limit']}"
        first = (
            "Now",
            [
                ("State", f"running on {nodes}" if nodes else "running"),
                ("Ends", ends),
                ("Time used", used),
                (
                    "Note",
                    "close to its time limit; it is stopped when it gets there"
                    if sjobs.near_limit(job)
                    else "",
                ),
            ],
        )
    elif category == "PENDING":
        why = job["reason"]
        slurm_reason = value("state_reason")
        if slurm_reason and slurm_reason not in ("None", why):
            why = f"{why} (Slurm: {slurm_reason})" if why else slurm_reason
        starts = job["est_start_at"]
        if starts:
            starts = f"~{starts} ({job['_est_start_in']}), Slurm's estimate"
        first = (
            "Waiting",
            [
                ("Why", why),
                ("Note", job.get("_hint", "")),
                ("Starts", starts),
                ("Waited", job["waiting"]),
                ("Free now", job.get("_idle", "")),
                ("Priority", job["priority"]),
                ("Fair share", job.get("_fairshare", "")),
            ],
        )
    else:
        first = (
            "Outcome",
            [
                ("State", job["outcome"] or job["state_label"]),
                ("Why", job.get("_hint", "")),
                ("Ran", job["ran"]),
                ("Ended", job["ended"]),
            ],
        )
    sections = [first]
    if check:
        sections.append(("Check", list(check)))
    sections += [
        (
            "Resources",
            [
                ("CPUs", job["cpus"]),
                ("Memory", job["mem"]),
                ("GPUs", job["gpus"]),
                ("Nodes", nodes if category != "RUNNING" else ""),
                ("Constraint", value("features")),
                ("Time limit", job["time_limit"]),
            ],
        ),
        (
            "Files",
            [
                ("Directory", value("current_working_directory")),
                ("Output", job["_output"]),
                ("Errors", "" if errors == job["_output"] else errors),
                ("Script", value("command")),
            ],
        ),
        (
            "Job",
            [
                ("ID", job["job_id"]),
                ("Name", job["name"]),
                ("User", job["user"]),
                ("Account", value("account")),
                ("QOS", value("qos")),
                ("Partition", job["partition"]),
                ("Submitted", job["submitted"]),
            ],
        ),
    ]
    return [
        (title, [(label, text) for label, text in rows if text])
        for title, rows in sections
    ]


def labeled(rows, label_style="", label_width=None):
    """Label and value columns; long values wrap within their column."""
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style=label_style, no_wrap=True, min_width=label_width)
    grid.add_column(overflow="fold")
    for label, value in rows:
        grid.add_row(label, value)
    return Padding(grid, (0, 0, 0, 2))


def sectioned(sections, label_style="", label_width=None):
    """Bold titles, each over its labeled rows, a blank line between."""
    parts = []
    for index, (title, rows) in enumerate(sections):
        heading = Text(title, style="bold")
        parts += [Text()] * bool(index) + [
            heading,
            labeled(rows, label_style, label_width),
        ]
    return Group(*parts)


def detail_text(job, check=None):
    """detail_sections, laid out; a user's row shows their totals."""
    muted = sjobs.resolve_style("muted")
    if job.get("_group") is not None:
        jobs = sum(len(row.get("_tasks", ())) or 1 for row in job["_members"])
        rows = [("Jobs", str(jobs))]
        if job["resources"]:
            rows.append(("Resources", job["resources"]))
        if job.get("outcome"):
            rows.append(("Outcomes", job["outcome"]))
        return Group(
            sectioned([("User", rows)], muted),
            Text(),
            Text("Space shows or hides their jobs.", style=muted),
        )
    if job.get("_tasks"):
        job = job["_tasks"][0]
    sections = [(title, rows) for title, rows in detail_sections(job, check) if rows]
    width = max(len(label) for _title, rows in sections for label, _value in rows)
    return sectioned(sections, muted, width)


def detail_title(job):
    if job.get("_group") is not None:
        return job["name"]
    if job.get("_tasks"):
        job = job["_tasks"][0]
    return f"{job['name'] or 'unnamed'}  {job['job_id']}"


def muted_color(foreground, background, amount=0.3):
    """A gray between the text and the background that stays readable on
    light themes, where dim text is too faint."""
    try:
        return Color.parse(foreground).blend(Color.parse(background), amount).hex
    except Exception:  # noqa: BLE001 - any unreadable color: fall back to dim
        return "dim"


class ThinScrollBarRender(ScrollBarRender):
    """Scrollbars drawn as a thin line on an invisible track."""

    @classmethod
    def render_bar(
        cls,
        size=25,
        virtual_size=50,
        window_size=20,
        position=0,
        thickness=1,
        vertical=True,
        back_color=None,
        bar_color=None,
    ):
        size = int(size)
        width = thickness if vertical else 1
        before = Segment(
            " " * width, Style(bgcolor=back_color, meta={"@mouse.down": "scroll_up"})
        )
        after = Segment(
            " " * width, Style(bgcolor=back_color, meta={"@mouse.down": "scroll_down"})
        )
        segments = [before] * size
        if window_size and size and virtual_size and virtual_size > window_size:
            thumb = max(1, round(size * window_size / virtual_size))
            start = round((size - thumb) * position / (virtual_size - window_size))
            line = Segment(
                ("┃" if vertical else "━") * width,
                Style(
                    color=bar_color, bgcolor=back_color, meta={"@mouse.down": "grab"}
                ),
            )
            segments[start : start + thumb] = [line] * thumb
            segments[start + thumb :] = [after] * (size - start - thumb)
        if vertical:
            return Segments(segments, new_lines=True)
        return Segments((segments + [Segment.line()]) * thickness, new_lines=False)


class SectionRule(Static):
    """A category's rule line, drawn for the width it has when painted, so
    it never wraps after the window narrows."""

    rule = None

    def show(self, *rule):
        """The rule for category_title(*rule); None shows plain content."""
        self.rule = rule
        self.update(sjobs.category_title(*rule))

    def show_text(self, text):
        self.rule = None
        self.update(text)

    def render(self):
        if self.rule is None:
            return super().render()
        return sjobs.category_title(*self.rule, width=self.content_size.width)


class JobTable(DataTable):
    """A category's table; ↓ on its last row and ↑ on its first move on to the
    next or previous table, so the stacked tables read as one list."""

    # Enter selects the row, which opens or closes the details pane.
    BINDINGS: ClassVar = [Binding("enter", "select_cursor", "Details", key_display="⏎")]

    def action_cursor_down(self):
        at_end = self.cursor_row >= self.row_count - 1
        if not (at_end and self.app.move_between_tables(self, 1)):
            super().action_cursor_down()

    def action_cursor_up(self):
        if not (self.cursor_row <= 0 and self.app.move_between_tables(self, -1)):
            super().action_cursor_up()


class TextScreen(ModalScreen):
    """A scrollable page with a title; Esc closes it."""

    BINDINGS: ClassVar = [Binding("escape,q", "dismiss", "Close")]
    HINT = "Esc to close"

    def __init__(self, title, body):
        super().__init__()
        self.title_text = title
        self.body = body

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Static(Text(self.title_text, style="bold"), id="dialog-title")
            with VerticalScroll():
                yield Static(self.body, id="body")
            yield Static(
                Text(self.HINT, style=sjobs.resolve_style("muted")), classes="hint"
            )


class HelpScreen(TextScreen):
    """What sjobs shows and which keys it has."""

    BINDINGS: ClassVar = [Binding("escape,q,question_mark", "dismiss", "Close")]

    def __init__(self, keys, refresh):
        muted = sjobs.resolve_style("muted")
        marks = [
            (Text(mark, style=sjobs.resolve_style(style)), description)
            for mark, style, description in (
                ("●", "running", "running"),
                ("●", "warn", "running, within 10% of its time limit"),
                ("○", "muted", "pending, waiting its turn"),
                (
                    "!",
                    "warn",
                    "pending: held, or waiting on something outside the queue",
                ),
                ("✗", "error", "failed, or pending and will never start: act on it"),
                ("✓", "ok", "completed"),
                ("·", "muted", "other states, such as completing"),
                ("▸ ▾", "muted", "array job or user, folded or open; Space toggles"),
            )
        ]
        reading = [
            (
                "Times",
                (
                    "Ends and Starts are clock times, Waited and Ran durations. "
                    "Starts is Slurm's estimate (~) and shows only when Slurm has one."
                ),
            ),
            (
                "Why",
                (
                    "'in line': jobs with a higher priority go first. 'next': it has "
                    "the highest priority and starts when nodes free up. Faint "
                    "reasons are routine; red ones need you."
                ),
            ),
            (
                "Fair share",
                (
                    "(top line) how much of your share of the cluster you have "
                    "used lately: good, fair or low. The more you used, the "
                    "lower your pending jobs rank."
                ),
            ),
            (
                "Finished",
                (
                    "Slurm forgets finished jobs after a few minutes. sjobs keeps "
                    "those that end while it runs, until you quit."
                ),
            ),
            (
                "Names",
                (
                    "jobs with the same name show the end of their directory; "
                    "arrays show how many tasks are done."
                ),
            ),
            (
                "Narrow",
                (
                    "windows hide the least useful columns first (the ID, then "
                    "limits and waits); the section line says how many."
                ),
            ),
        ]
        body = Group(
            sectioned(
                [("Keys", keys), ("Marks", marks), ("Reading the tables", reading)],
                "bold",
                11,
            ),
            Text(),
            Text(
                f"The tables refresh every {refresh} s, with one squeue call. "
                "Checking a job (h in its details), its log (l) and cancelling "
                "(c) are extra calls, made only when asked.",
                style=muted,
            ),
        )
        super().__init__("sjobs help", body)


class LogScreen(ModalScreen):
    """The end of a job's output file, read when opened."""

    BINDINGS: ClassVar = [
        Binding("escape,q,l", "dismiss", "Close"),
        Binding("r", "reload", "Reload"),
        Binding("e", "toggle_stream", "Output/errors"),
    ]

    def __init__(self, job, host):
        super().__init__()
        self.job = job
        self.host = host
        self.paths = [
            job["_output"],
            job["_errors"],
        ]
        if self.paths[1] in ("", self.paths[0]):
            self.paths.pop()
        self.stream = 0

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog"):
            yield Static(id="dialog-title")
            with VerticalScroll(id="log-scroll"):
                yield Static(Text("Loading…", style="dim"), id="body")
            hint = f"last {LOG_LINES} lines · r to reload"
            if len(self.paths) > 1:
                hint += " · e for output/errors"
            hint += " · Esc to close"
            yield Static(Text(hint, style=sjobs.resolve_style("muted")), classes="hint")

    def on_mount(self):
        self.action_reload()

    def action_toggle_stream(self):
        if len(self.paths) > 1:
            self.stream = 1 - self.stream
            self.action_reload()

    def action_reload(self):
        path = self.paths[self.stream]
        label = "Errors" if self.stream else "Output"
        self.query_one("#dialog-title", Static).update(
            Text.assemble(
                (f"{label} of job {self.job['job_id']}", "bold"), (f"  {path}", "dim")
            )
        )
        self.load(path)

    @work(thread=True, exclusive=True)
    def load(self, path):
        try:
            text = Text(sjobs.run_tail(path, self.host, LOG_LINES) or "(empty)")
        except click.ClickException as exc:
            text = Text(exc.format_message(), style="red")
        self.app.call_from_thread(self.show, text)

    def show(self, text):
        self.query_one("#body", Static).update(text)
        self.query_one("#log-scroll", VerticalScroll).scroll_end(animate=False)


class ColumnChooser(ModalScreen):
    """Pick optional columns; closing applies the choice."""

    BINDINGS: ClassVar = [
        Binding("escape,o", "close", "Done"),
        # Enter would otherwise toggle the highlighted entry.
        Binding("enter", "close", "Done", priority=True),
    ]

    def __init__(self, columns):
        super().__init__()
        self.columns = columns

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog", classes="small"):
            yield Static(Text("Optional columns", style="bold"), id="dialog-title")
            yield SelectionList(
                *(
                    (f"{key:<10} {description}", key, key in self.columns)
                    for key, description in sjobs.OPTIONAL_COLUMNS.items()
                )
            )
            yield Static(
                Text(
                    "Space to toggle · Enter when done",
                    style=sjobs.resolve_style("muted"),
                ),
                classes="hint",
            )

    def on_mount(self):
        self.query_one(SelectionList).focus()

    def action_close(self):
        self.dismiss(tuple(self.query_one(SelectionList).selected))


class ConfirmCancel(ModalScreen[bool]):
    """Asks before running scancel."""

    BINDINGS: ClassVar = [
        Binding("y", "answer(True)", "Cancel the job"),
        Binding("n,escape,q", "answer(False)", "Keep it"),
    ]

    def __init__(self, job):
        super().__init__()
        self.job = job

    def compose(self) -> ComposeResult:
        with Vertical(id="dialog", classes="small"):
            yield Static(
                Text.assemble(
                    "Cancel job ",
                    (self.job["job_id"], "bold"),
                    f" ({self.job['name'] or 'unnamed'})? ",
                    ("y", "bold red"),
                    "/",
                    ("n", "bold"),
                )
            )

    def action_answer(self, answer):
        self.dismiss(answer)


class SjobsApp(App):
    """Job tables that refresh themselves; see BINDINGS for the keys."""

    TITLE = "sjobs"
    CSS = """
    /* Thin, faint scrollbars that only stand out while used. Only on what
       scrolls: the footer, for one, keeps its hidden scrollbar. */
    DataTable, VerticalScroll, SelectionList {
        scrollbar-size: 1 1;
        scrollbar-background: $background;
        scrollbar-background-hover: $background;
        scrollbar-background-active: $background;
        scrollbar-color: $foreground 30%;
        scrollbar-color-hover: $foreground 50%;
        scrollbar-color-active: $primary 60%;
        scrollbar-corner-color: $background;
    }
    #header { height: 1; padding: 0 1; }
    #where { width: 1fr; height: 1; }
    #status { width: auto; height: 1; }
    #attention { padding: 0 1; height: auto; display: none; }
    #attention.shown { display: block; }
    #filter { display: none; margin: 0 1; }
    #filter.shown { display: block; }
    #tabs { display: none; margin: 1 1 0 1; }
    #tabs.shown { display: block; }
    #main { height: 1fr; }
    /* Only the tables scroll sideways, not the page around them. */
    #tables { width: 1fr; height: 1fr; overflow-x: hidden; }
    #preview {
        display: none; width: PREVIEW_WIDTH; height: 1fr;
        padding: 1 1 0 2; border-left: solid $foreground 15%;
    }
    #preview.shown { display: block; }
    /* Narrow windows: the pane below the tables, the cursor row in view. */
    #main.below { layout: vertical; }
    #main.below #preview {
        width: 100%; height: 45%;
        padding: 0 1 0 2; border-left: none; border-top: solid $foreground 15%;
    }
    /* Short windows: the pane covers the tables; arrows still move the
       cursor and the pane's title says which job it shows. */
    #main.over #tables { display: none; }
    #main.over #preview { width: 100%; border-left: none; padding: 1 1 0 2; }
    #empty { width: 100%; height: auto; margin-top: 3; text-align: center; }
    .category { padding: 1 1 0 1; }
    .tabbed .category { padding: 0 1; }
    DataTable { height: auto; max-height: 100%; margin: 0 1; }
    /* Flat tables on the theme's background. The focused table marks its
       cursor row with a tint of the primary color; other tables show none. */
    DataTable, DataTable:focus { background: $background; background-tint: 0%; }
    DataTable > .datatable--header, DataTable:focus > .datatable--header {
        background: $background; background-tint: 0%;
        color: $foreground; text-style: bold;
    }
    DataTable > .datatable--even-row, DataTable > .datatable--hover {
        background: $background;
    }
    DataTable > .datatable--cursor {
        background: $background; color: $foreground; text-style: none;
    }
    DataTable:focus > .datatable--cursor {
        background: $primary 25%; text-style: none;
    }
    SelectionList, SelectionList:focus { background: $background; background-tint: 0%; }
    SelectionList > .option-list--option-highlighted,
    SelectionList:focus > .option-list--option-highlighted {
        background: $primary 25%; color: $foreground; text-style: none;
    }
    TextScreen, LogScreen, ColumnChooser, ConfirmCancel { align: center middle; }
    #dialog {
        width: 90%; max-width: 110; height: 85%; padding: 1 2;
        border: round $primary; background: $background;
    }
    #dialog.small { width: auto; height: auto; }
    /* A fill width (Static's default) is 0 inside an auto-width dialog. */
    #dialog.small > Static { width: auto; }
    #dialog-title, .hint { height: auto; }
    #dialog-title { padding-bottom: 1; }
    .hint { padding-top: 1; }
    SelectionList { height: auto; width: auto; border: none; }
    """.replace("PREVIEW_WIDTH", str(PREVIEW_WIDTH))
    # The footer shows the keys used most; ? lists them all.
    BINDINGS: ClassVar = [
        Binding("slash", "filter", "Filter"),
        Binding("l", "log", "Log"),
        Binding("c", "cancel_job", "Cancel"),
        Binding("a", "toggle_all", "Mine/all"),
        # Space has two bindings; check_action shows the one for the row.
        Binding("space", "expand", "Expand"),
        Binding("space", "fold", "Fold"),
        Binding("question_mark", "help", "Help"),
        Binding("q", "quit", "Quit"),
        Binding("ctrl+c", "quit", "Quit", show=False, priority=True),
        Binding("y", "copy_id", "Copy ID", show=False),
        Binding("escape", "escape", "Close details, clear filter", show=False),
        Binding("o", "columns", "Columns", show=False),
        Binding("r", "refresh_now", "Refresh", show=False),
        Binding("t", "toggle_layout", "Layout", show=False),
        Binding("h", "check", "Check", show=False),
        Binding("1", "show_category('RUNNING')", "Running", show=False),
        Binding("2", "show_category('PENDING')", "Pending", show=False),
        Binding("3", "show_category('OTHER')", "Finished", show=False),
    ]
    KEYS = (
        ("↑ ↓", "move through the jobs, across tables"),
        ("1 2 3", "jump to running, pending, finished"),
        (
            "Enter",
            "details of the selected row, beside or below the tables; again closes",
        ),
        ("h", "check a running job: output last written, memory and CPU use"),
        ("Space", "expand or fold an array job, or a user's jobs"),
        ("l", "end of the selected job's output file"),
        ("/", "filter by ID, name, user, path, partition or reason"),
        ("Esc", "close the details, clear the filter, close a window"),
        ("c", "cancel the selected job (asks first)"),
        ("a", "your jobs or all users' jobs"),
        ("o", "choose optional columns"),
        ("t", "tables one above the other, or as tabs"),
        ("y", "copy the selected job's ID"),
        ("r", "refresh now"),
        ("Ctrl+P", "commands, including other color themes"),
        ("q", "quit"),
    )
    # Stacked tables become tabs when they need this many more rows than the
    # window has, and come back when they fit again.
    TAB_THRESHOLD_MARGIN = 4

    def __init__(
        self,
        show_all=False,
        username=None,
        host=None,
        config=None,
        interval=sjobs.DEFAULT_INTERVAL,
        columns=(),
        terminal_colors=None,
    ):
        super().__init__()
        self.show_all = show_all
        self.username = username
        self.host = host
        self.config = config or {}
        self.interval = interval
        self.columns = tuple(columns)
        self.terminal_colors = terminal_colors
        self.snapshot = None
        self.snapshot_scope = None
        self.error = None
        self.fetched_at = None
        self.last_request = 0.0
        self.next_refresh = None
        self.busy = False
        self.filter_text = ""
        self.expanded = set()
        # Users whose jobs show in the all-users view; yours, at first.
        self.expanded_users = None
        # Jobs that ended and left squeue while sjobs ran, by job key.
        self.history = {}
        self.started_at = time.time()
        # Start of the sacct history (history_hours), once it has arrived.
        self.history_since = None
        self.history_problem = None
        # Results of on-demand job checks, by job key.
        self.checks = {}
        # Job keys that just started or ended, until a monotonic time.
        self.changed = {}
        self.layout = self.config.get("layout", "auto")
        self.tabbed = self.layout == "tabs"
        # The details pane, off until Enter or p.
        self.preview_wanted = False
        self.active = "RUNNING"
        # Rows in display order per category, so a cursor row maps to its job.
        self.rows = {name: [] for name in sjobs.CATEGORIES}

    @property
    def by_user(self):
        """All users' jobs are shown one row per user."""
        return self.show_all and not self.username

    def own_users(self):
        """Your user name(s), from sshare; None when unknown."""
        if self.snapshot is None or not self.snapshot["shares"]:
            return None
        return {row["user"] for row in self.snapshot["shares"]}

    def compose(self) -> ComposeResult:
        with Horizontal(id="header"):
            yield Static(id="where")
            yield Static(id="status")
        yield Static(id="attention")
        yield Input(placeholder="filter by ID, name, user, path, reason…", id="filter")
        yield Tabs(
            *(
                Tab(spec["title"], id=f"tab-{name}")
                for name, spec in sjobs.CATEGORIES.items()
            ),
            id="tabs",
        )
        with Horizontal(id="main"):
            with VerticalScroll(id="tables"):
                for name in sjobs.CATEGORIES:
                    yield SectionRule(id=f"label-{name}", classes="category")
                    yield JobTable(
                        id=f"table-{name}",
                        cursor_type="row",
                        # Cells keep their colors (marks, bars, faint text)
                        # under the cursor, which only tints the background.
                        cursor_foreground_priority="renderable",
                    )
                yield Static(id="empty")
            with VerticalScroll(id="preview"):
                yield Static(id="preview-title")
                yield Static(id="preview-body")
                yield Static(id="preview-hint", classes="hint")
        yield Footer()

    def check_action(self, action, parameters):
        """While a dialog is open, only quitting reaches the app. Expand and
        Fold only apply to (and only show in the footer for) rows they change."""
        if isinstance(self.screen, ModalScreen):
            return action == "quit"
        if action == "expand":
            return self.expand_target() is not None
        if action == "fold":
            return self.expand_target() is None and self.fold_target() is not None
        return True

    def expand_target(self):
        """What Space opens on the selected row: ("array", ID) or ("user", name)."""
        row = self.selected_job()
        if row is None:
            return None
        if row.get("_group") is not None:
            user = row["_group"]
            return None if user in (self.expanded_users or ()) else ("user", user)
        if row.get("_tasks"):
            return ("array", row["_tasks"][0]["_array_id"][0])
        return None

    def fold_target(self):
        """What Space closes on the selected row."""
        row = self.selected_job()
        if row is None:
            return None
        if row.get("_group") is not None:
            return ("user", row["_group"])
        array = row.get("_array_job")
        if not row.get("_tasks") and array is not None and array in self.expanded:
            return ("array", array)
        if row.get("_indent"):
            return ("user", row["user"])
        return None

    def on_data_table_row_highlighted(self, _event):
        self.refresh_bindings()
        self.redraw_preview()

    def on_descendant_focus(self, _event):
        self.refresh_bindings()
        self.redraw_preview()

    def on_mount(self):
        ScrollBar.renderer = ThinScrollBarRender
        self.apply_theme(self.config.get("theme") or AUTO_THEME)
        self.theme_changed_signal.subscribe(self, lambda _theme: self.redraw())
        self.redraw()
        self.timer = self.set_interval(self.interval, self.refresh_jobs)
        self.set_interval(1, self.redraw_status)
        self.refresh_jobs()
        self.load_history()

    def apply_theme(self, wanted):
        """The configured theme; by default one made of the terminal's colors,
        else Textual's light or dark theme to match the terminal."""
        for ayu in AYU_THEMES:
            self.register_theme(ayu)
        theme, ansi = terminal_themes(self.terminal_colors)
        if theme is not None:
            self.register_theme(theme)
        if ansi is not None:
            # ANSI colors in cells (red, green, …) then use the terminal's own.
            self.ansi_theme_dark = self.ansi_theme_light = ansi
        if wanted != AUTO_THEME and wanted not in self.available_themes:
            self.notify(f"Unknown theme {wanted!r}; using the terminal's colors.")
            wanted = AUTO_THEME
        if wanted == AUTO_THEME:
            background = (self.terminal_colors or {}).get("background")
            if theme is not None:
                wanted = TERMINAL_THEME
            elif background is not None and luminance(background) > 0.5:
                wanted = "textual-light"
            else:
                wanted = "textual-dark"
        self.theme = wanted

    def update_muted(self):
        """Faint text in a gray made of the current theme's colors."""
        variables = self.get_css_variables()
        foreground = variables.get("foreground")
        background = variables.get("background")
        if foreground and background:
            sjobs.STYLES["muted"] = muted_color(foreground, background)

    def on_resize(self, _event):
        # Tabs or stacked tables, and which columns fit, depend on the size;
        # decide once sizes settle.
        if self.snapshot is not None:
            self.call_after_refresh(self.redraw)

    # Fetching -----------------------------------------------------------------

    def refresh_jobs(self):
        """Start one fetch in a worker thread; a newer one replaces a running one."""
        self.last_request = time.monotonic()
        self.next_refresh = self.last_request + self.interval
        self.busy = True
        self.redraw_status()
        self.fetch()

    @work(thread=True, exclusive=True, group="fetch")
    def fetch(self):
        now = time.time()
        scope = (self.show_all, self.username)
        try:
            snapshot = sjobs.fetch_snapshot(
                show_all=self.show_all,
                username=self.username,
                host=self.host,
                config=self.config,
                now=now,
            )
            error = None
        except click.ClickException as exc:
            snapshot, error = None, exc.format_message()
        self.call_from_thread(self.apply_snapshot, snapshot, error, now, scope)

    def apply_snapshot(self, snapshot, error, now, scope=None):
        """Show a fetch result; a failed fetch keeps the last good tables.

        A result for another scope (mine or all, from before a switch) is
        dropped; the first one after a switch is shown without comparing it
        to the last, as its jobs did not start or end, they came into view.
        """
        if scope is not None and scope != (self.show_all, self.username):
            return
        self.busy = False
        self.error = error
        if snapshot is not None:
            if self.snapshot is not None and self.snapshot_scope == scope:
                changes = sjobs.job_changes(self.snapshot["jobs"], snapshot["jobs"])
                self.announce(changes)
                self.mark_changed(job for job, _event, _severity in changes)
                self.remember_finished(self.snapshot["jobs"], snapshot["jobs"], now)
            self.snapshot = snapshot
            self.snapshot_scope = scope
            self.fetched_at = now
        self.redraw()

    def remember_finished(self, old_jobs, new_jobs, now):
        """Keep jobs that left squeue: finished ones as they were last seen,
        running ones as ended (Slurm no longer says how)."""
        present = {sjobs.job_key(job) for job in new_jobs}
        for key in present:
            self.history.pop(key, None)
        for job in old_jobs:
            key = sjobs.job_key(job)
            if key in present:
                continue
            category = sjobs.classify_job(job)
            if category == "OTHER":
                self.history[key] = job
            elif category == "RUNNING":
                self.history[key] = {
                    **job,
                    "state": "ENDED",
                    "state_label": "ended",
                    "outcome": "ended",
                    "note": "left the queue",
                    "progress": "",
                    "end_time": "",
                    "ended": sjobs.format_when(now, now),
                    "_ended": -now,
                    "_severity": None,
                    "_hint": "It left the queue between two refreshes, so "
                    "Slurm no longer says how it ended.",
                    "glyph": sjobs.GLYPHS["OTHER"][0],
                    "_glyph_style": sjobs.GLYPHS["OTHER"][1],
                }
        self.trim_history()

    def mark_changed(self, jobs):
        until = time.monotonic() + CHANGED_SECONDS
        keys = [sjobs.job_key(job) for job in jobs]
        for key in keys:
            self.changed[key] = until
        if keys:
            self.set_timer(CHANGED_SECONDS + 0.1, self.redraw)

    def announce(self, changes, limit=3):
        """Tell the user which jobs started or ended since the last refresh."""
        messages = [
            (sjobs.describe_change(job, event), severity)
            for job, event, severity in changes
        ]
        for message, severity in messages[:limit]:
            self.notify(
                message,
                severity="error" if severity == "error" else "information",
                timeout=10,
                markup=False,
            )
        if len(messages) > limit:
            self.notify(f"and {len(messages) - limit} more jobs changed", timeout=10)
        if messages and self.config.get("desktop_notifications"):
            text = (
                messages[0][0]
                if len(messages) == 1
                else (f"{len(messages)} jobs changed: {messages[0][0]}, …")
            )
            self.desktop_notify(text)

    def desktop_notify(self, text):
        """A desktop notification through the terminal (OSC 9), where supported."""
        driver = getattr(self, "_driver", None)
        if driver is not None:
            clean = "".join(char for char in text if char.isprintable())
            driver.write(f"\x1b]9;sjobs: {clean}\x07")

    # Drawing ------------------------------------------------------------------

    def all_jobs(self):
        """squeue's jobs plus finished ones it has forgotten."""
        jobs = list(self.snapshot["jobs"]) if self.snapshot else []
        present = {sjobs.job_key(job) for job in jobs}
        jobs += [job for key, job in self.history.items() if key not in present]
        return jobs

    def visible_jobs(self, jobs):
        if self.filter_text:
            jobs = [job for job in jobs if matches(job, self.filter_text)]
        return jobs

    def redraw(self):
        self.update_muted()
        jobs = self.all_jobs()
        visible = self.visible_jobs(jobs)
        if "cwd" in self.columns:
            for job in visible:
                job["_where"] = ""
        else:
            sjobs.disambiguate(visible)
        summaries = sjobs.array_summaries(jobs)
        all_grouped = sjobs.group_jobs(jobs)
        grouped = sjobs.group_jobs(visible)
        own = self.own_users()
        if self.by_user and self.expanded_users is None and own is not None:
            self.expanded_users = set(own)
        rows = {
            name: sjobs.category_rows(
                name,
                grouped[name],
                self.expanded,
                summaries,
                by_user=self.by_user,
                users=self.expanded_users or (),
                first=own or (),
            )
            for name in sjobs.CATEGORIES
        }
        self.redraw_header(all_grouped)
        focused = self.focused
        self.update_layout(rows, grouped)
        fields = {
            name: sjobs.shown_fields(
                sjobs.category_fields(name, self.columns), rows[name]
            )
            for name in sjobs.CATEGORIES
        }
        if self.tabbed:
            widths = {
                name: sjobs.fit_widths(fields[name], rows[name])
                for name in sjobs.CATEGORIES
            }
        else:
            # Stacked tables share the widths of their common leading columns.
            shown = {name: (fields[name], rows[name]) for name in rows if rows[name]}
            widths = sjobs.align_widths(shown)
        available = self.table_space()
        for name in sjobs.CATEGORIES:
            fitted = sjobs.fit_columns(
                fields[name],
                widths.get(name) or sjobs.fit_widths(fields[name], rows[name]),
                available,
            )
            self.redraw_table(
                name,
                rows[name],
                len(grouped[name]),
                len(all_grouped[name]),
                *fitted,
            )
        self.redraw_empty(rows)
        if not isinstance(focused, DataTable | Input) or not focused.display:
            self.focus_first_table()
        self.redraw_preview()

    def preview_place(self):
        """Where the details pane is: "side", "below", "over" or None."""
        if not self.preview_wanted:
            return None
        if self.size.width >= PREVIEW_MIN_WIDTH:
            return "side"
        return "below" if self.size.height >= PREVIEW_MIN_HEIGHT else "over"

    def preview_shown(self):
        return self.preview_place() is not None

    def table_space(self):
        """Cells a table can use: the window less a details pane beside it,
        margins and the scrollbar."""
        side = self.preview_place() == "side"
        width = self.size.width - (PREVIEW_WIDTH if side else 0)
        return max(width - 3, 20)

    def update_layout(self, rows, grouped):
        """Stacked tables while they fit, else tabs with one category each."""
        needed = sum(len(r) + 3 for r in rows.values() if r)
        height = self.query_one("#tables").size.height or self.size.height
        if self.layout == "auto":
            if self.tabbed:
                self.tabbed = needed > height
            else:
                self.tabbed = needed > height + self.TAB_THRESHOLD_MARGIN
        else:
            self.tabbed = self.layout == "tabs"
        tabs = self.query_one("#tabs", Tabs)
        tabs.set_class(self.tabbed, "shown")
        self.query_one("#tables").set_class(self.tabbed, "tabbed")
        for name, spec in sjobs.CATEGORIES.items():
            tab = tabs.query_one(f"#tab-{name}", Tab)
            tab.label = f"{spec['title']} {len(grouped[name])}"
        if self.tabbed and not rows[self.active]:
            self.active = next((n for n in rows if rows[n]), self.active)
        if self.tabbed and tabs.active != f"tab-{self.active}":
            tabs.active = f"tab-{self.active}"
        place = self.preview_place()
        main = self.query_one("#main")
        main.set_class(place == "below", "below")
        main.set_class(place == "over", "over")
        self.query_one("#preview").set_class(place is not None, "shown")

    def redraw_header(self, grouped):
        """Where and whose jobs, resources in use, and what needs you."""
        jobs = self.snapshot["jobs"] if self.snapshot else []
        live = sjobs.group_jobs(jobs)
        scope = sjobs.scope_label(self.show_all, self.username)
        # Fair share (yours, or --user's) matters in any view, for one
        # when deciding what to submit next.
        shares = self.snapshot["shares"] if self.snapshot else None
        self.query_one("#where", Static).update(
            sjobs.render_header(live, self.host, scope, shares)
        )
        self.redraw_status()
        lines = []
        if self.snapshot is not None:
            own = self.own_users()
            if self.by_user and own is None:
                own = set()
            lines += sjobs.attention_lines(grouped, time.time(), own=own)
        if self.error:
            lines.append(
                Text(f"Error: {self.error}", style=sjobs.resolve_style("error"))
            )
        if self.snapshot is not None:
            lines += sjobs.render_notes(live, self.snapshot)
        if self.history_problem:
            lines.append(
                Text(
                    f"job history unavailable: {self.history_problem}",
                    style=sjobs.resolve_style("muted"),
                )
            )
        attention = self.query_one("#attention", Static)
        attention.update(Text("\n").join(lines))
        attention.set_class(bool(lines), "shown")

    def redraw_status(self):
        left = None
        if self.next_refresh is not None:
            left = self.next_refresh - time.monotonic()
        try:
            status = self.query_one("#status", Static)
        except NoMatches:
            return  # The app is closing.
        status.update(
            sjobs.render_status(
                self.fetched_at, left, self.busy, failed=self.error is not None
            )
        )

    def section_note(self, name, rows, dropped):
        """Context at the right of a section line."""
        notes = []
        muted = sjobs.resolve_style("muted")
        # Hidden columns first: a long line cuts the notes at its end.
        if dropped:
            hidden = sjobs.plural(len(dropped), "column")
            notes.append(Text(f"{hidden} hidden", style=muted))
        if name == "OTHER" and self.history:
            since = self.history_since or self.started_at
            when = sjobs.format_when(since, time.time())
            notes.append(Text(f"since {when}", style=muted))
        if not notes:
            return None
        return Text(" · ", style=muted).join(notes)

    def redraw_table(self, name, rows, shown, total, fields, widths, dropped):
        label = self.query_one(f"#label-{name}", SectionRule)
        table = self.query_one(f"#table-{name}", DataTable)
        selected = self.selected_job(table)
        self.rows[name] = rows

        visible = bool(rows) and (not self.tabbed or name == self.active)
        table.display = visible
        note = self.section_note(name, rows, dropped)
        if self.tabbed:
            # The tab carries the title and count; the line only its notes.
            label.display = visible and note is not None
            if note is not None:
                label.show_text(note)
        else:
            label.display = visible
            label.show(name, shown, total, note)

        table.clear(columns=True)
        for key, header in fields:
            justify = "right" if key in sjobs.RIGHT_ALIGNED else "left"
            table.add_column(Text(header, justify=justify), key=key, width=widths[key])
        now = time.monotonic()
        changed = sjobs.resolve_style("changed")
        for row in rows:
            cells = [sjobs.job_cell(row, key, widths) for key, _header in fields]
            if self.changed.get(row_key(row), 0) > now:
                for text in cells:
                    text.stylize(changed)
            table.add_row(*cells)
        if selected is not None:
            for index, row in enumerate(rows):
                if row_key(row) == row_key(selected):
                    table.move_cursor(row=index, scroll=False)
                    break

    def redraw_empty(self, rows):
        """A message in place of the tables when there is nothing to show."""
        empty = self.query_one("#empty", Static)
        if any(rows.values()):
            empty.display = False
            return
        empty.display = True
        muted = sjobs.resolve_style("muted")
        if self.snapshot is None:
            text = Text("Fetching jobs…", style=muted)
        elif self.filter_text:
            text = Text.assemble(
                f"No jobs match “{self.filter_text}”.\n",
                ("Esc clears the filter.", muted),
            )
        elif self.username:
            text = Text(f"{self.username} has no jobs in the queue.")
        elif self.show_all:
            text = Text("The queue is empty.")
        else:
            text = Text.assemble(
                "You have no jobs in the queue.\n",
                ("a shows all users' jobs.", muted),
            )
        empty.update(text)

    def redraw_preview(self):
        """The details pane follows the cursor."""
        if not self.preview_shown():
            return
        row = self.selected_job()
        title = self.query_one("#preview-title", Static)
        body = self.query_one("#preview-body", Static)
        hint = self.query_one("#preview-hint", Static)
        muted = sjobs.resolve_style("muted")
        if row is None:
            title.update("")
            body.update(Text("No job selected.", style=muted))
            hint.update("")
            return
        title.update(Text(detail_title(row) + "\n", style="bold"))
        job = (row.get("_tasks") or [row])[0]
        body.update(detail_text(row, self.checks.get(sjobs.job_key(job))))
        keys = ["Esc closes"]
        if row.get("_group") is None:
            keys[:0] = ["y copies the ID", "l shows the log"]
            if sjobs.classify_job(job) == "RUNNING":
                keys.insert(0, "h checks output and usage")
        hint.update(Text(" · ".join(keys), style=muted))

    # Selection ----------------------------------------------------------------

    def tables(self):
        return [
            self.query_one(f"#table-{name}", DataTable) for name in sjobs.CATEGORIES
        ]

    def focus_first_table(self):
        for table in self.tables():
            if table.display:
                table.focus()
                return
        # No table to focus (no jobs): focus nothing rather than leave it on
        # a hidden widget, such as the filter box, that would swallow keys.
        focused = self.focused
        if focused is not None and not (focused.display and focused.visible):
            self.set_focus(None)

    def selected_job(self, table=None):
        """The row under the cursor of the given (or the focused) table."""
        table = table or self.focused
        if not isinstance(table, DataTable) or not table.row_count:
            return None
        name = table.id.removeprefix("table-")
        rows = self.rows.get(name, [])
        if 0 <= table.cursor_row < len(rows):
            return rows[table.cursor_row]
        return None

    def job_for_action(self):
        """The selected job for log and cancel; a folded array stands for its
        first task. None (with a note) on a user's row or without a row."""
        job = self.selected_job()
        if job is None:
            self.notify("Select a job first.", severity="warning")
            return None
        if job.get("_group") is not None:
            self.notify("Select one of their jobs; Space shows them.")
            return None
        return job

    def move_between_tables(self, table, step):
        """Continue from the end of one stacked table into the next one."""
        if self.tabbed:
            return False
        visible = [
            other for other in self.tables() if other.display and other.row_count
        ]
        if table not in visible:
            return False
        index = visible.index(table) + step
        if not 0 <= index < len(visible):
            return False
        target = visible[index]
        target.focus()
        target.move_cursor(row=0 if step > 0 else target.row_count - 1)
        return True

    def on_tabs_tab_activated(self, event: Tabs.TabActivated):
        name = event.tab.id.removeprefix("tab-")
        if self.tabbed and name != self.active:
            self.active = name
            self.redraw()
            self.focus_first_table()

    # Actions ------------------------------------------------------------------

    def action_help(self):
        self.push_screen(HelpScreen(self.KEYS, self.interval))

    def action_show_category(self, name):
        if self.tabbed:
            self.active = name
            self.redraw()
        table = self.query_one(f"#table-{name}", DataTable)
        if table.display:
            table.focus()

    def action_refresh_now(self):
        if time.monotonic() - self.last_request < MIN_MANUAL_REFRESH:
            self.notify("Refreshed just now; try again in a few seconds.")
            return
        self.timer.reset()
        self.refresh_jobs()

    def action_toggle_all(self):
        if self.username:
            self.notify(f"Showing --user {self.username}; restart without it.")
            return
        self.show_all = not self.show_all
        # Finished jobs kept so far belong to the other view.
        self.history.clear()
        self.history_since = None
        self.expanded_users = None
        self.timer.reset()
        self.refresh_jobs()
        self.load_history()

    def load_history(self):
        """With `history_hours`, fill Finished from sacct, once per view.
        Not for all users' jobs: that would be a heavy accounting query."""
        hours = self.config.get("history_hours", 0)
        if hours and not self.by_user:
            self.fetch_history(hours, (self.show_all, self.username))

    @work(thread=True, exclusive=True, group="history")
    def fetch_history(self, hours, scope):
        try:
            jobs, problem = sjobs.fetch_history(
                hours, self.username, self.host, self.config
            )
        except click.ClickException as exc:
            jobs, problem = [], exc.format_message()
        self.call_from_thread(self.apply_history, jobs, problem, hours, scope)

    def apply_history(self, jobs, problem, hours, scope):
        if scope != (self.show_all, self.username):
            return  # Fetched for the other view.
        self.history_problem = problem
        present = {sjobs.job_key(job) for job in (self.snapshot or {}).get("jobs", [])}
        for job in jobs:
            key = sjobs.job_key(job)
            # What sjobs saw itself is newer than the accounting record.
            if key not in present and key not in self.history:
                self.history[key] = job
        self.trim_history()
        self.history_since = time.time() - hours * 3600
        self.redraw()

    def trim_history(self):
        if len(self.history) > HISTORY_LIMIT:
            newest = sorted(self.history.items(), key=lambda item: item[1]["_ended"])
            self.history = dict(newest[:HISTORY_LIMIT])

    def action_copy_id(self):
        job = self.job_for_action()
        if job is not None:
            self.copy_text(job["job_id"])

    def copy_text(self, text):
        """To the clipboard through the terminal (OSC 52), which also works
        over SSH where the terminal allows it."""
        self.copy_to_clipboard(text)
        shown = text if len(text) <= 40 else text[:39] + "…"
        self.notify(f"Copied {shown}", timeout=3, markup=False)

    def action_toggle_layout(self):
        self.layout = "stacked" if self.tabbed else "tabs"
        self.notify(
            "Tables as tabs." if self.layout == "tabs" else "Tables stacked.",
            timeout=3,
        )
        self.redraw()
        self.focus_first_table()

    def action_toggle_preview(self):
        self.set_preview(not self.preview_wanted)

    def set_preview(self, wanted):
        """Open or close the details pane; the tables refit once the pane
        has its size."""
        if wanted == self.preview_wanted:
            return
        self.preview_wanted = wanted
        self.redraw()
        self.call_after_refresh(self.redraw)

    def action_escape(self):
        """Esc closes the details pane first, then clears the filter."""
        if self.preview_wanted and not isinstance(self.focused, Input):
            self.set_preview(False)
        else:
            self.action_clear_filter()

    def action_expand(self):
        self.toggle(self.expand_target(), open_it=True)

    def action_fold(self):
        self.toggle(self.fold_target(), open_it=False)

    def toggle(self, target, open_it):
        if target is None:
            return
        kind, key = target
        if kind == "user":
            self.expanded_users = set(self.expanded_users or ())
            group = self.expanded_users
        else:
            group = self.expanded
        if open_it:
            group.add(key)
        else:
            group.discard(key)
        self.redraw()
        self.select(target)

    def select(self, target):
        """Put the cursor on the first row of an array job or a user."""
        table = self.focused
        if not isinstance(table, DataTable):
            return
        kind, key = target
        rows = self.rows[table.id.removeprefix("table-")]
        for index, row in enumerate(rows):
            if kind == "user":
                hit = row.get("_group") == key
            else:
                first = (row.get("_tasks") or [row])[0]
                hit = first.get("_array_job") == key
            if hit:
                table.move_cursor(row=index)
                return

    def action_columns(self):
        def chosen(columns):
            self.columns = columns
            self.redraw()

        self.push_screen(ColumnChooser(self.columns), chosen)

    def action_filter(self):
        box = self.query_one("#filter", Input)
        box.add_class("shown")
        box.focus()

    def action_clear_filter(self):
        box = self.query_one("#filter", Input)
        box.value = ""
        box.remove_class("shown")
        self.filter_text = ""
        self.redraw()
        self.focus_first_table()

    def on_input_changed(self, event: Input.Changed):
        self.filter_text = event.value.strip()
        self.redraw()

    def on_input_submitted(self, _event: Input.Submitted):
        if not self.filter_text:
            self.query_one("#filter", Input).remove_class("shown")
        self.focus_first_table()

    def on_data_table_row_selected(self, _event: DataTable.RowSelected):
        """Enter opens or closes the details pane, for a job or a user's row."""
        self.action_toggle_preview()

    def action_check(self):
        """Check the selected running job; the results show in the details
        pane, which opens for them."""
        job = self.job_for_action()
        if job is None:
            return
        job = (job.get("_tasks") or [job])[0]
        if sjobs.classify_job(job) != "RUNNING":
            self.notify("Only running jobs can be checked.", timeout=3)
            return
        self.start_check(job)
        self.set_preview(True)

    def start_check(self, job):
        self.show_check(sjobs.job_key(job), [("Checking", "…")])
        self.run_job_check(job)

    @work(thread=True, exclusive=True, group="check")
    def run_job_check(self, job):
        try:
            rows = sjobs.run_check(job, self.host)
        except click.ClickException as exc:
            rows = [("Check failed", exc.format_message())]
        checked = ("Checked", time.strftime("%H:%M"))
        self.call_from_thread(self.show_check, sjobs.job_key(job), [checked, *rows])

    def show_check(self, key, rows):
        self.checks[key] = rows
        self.redraw_preview()

    def action_log(self):
        job = self.job_for_action()
        if job is None:
            return
        if job.get("_tasks"):
            job = job["_tasks"][0]
        if not job["_output"]:
            self.notify("Slurm reports no output file for this job.")
        else:
            self.push_screen(LogScreen(job, self.host))

    def action_cancel_job(self):
        job = self.job_for_action()
        if job is None:
            return

        def answered(confirmed):
            if confirmed:
                self.cancel(job)

        self.push_screen(ConfirmCancel(job), answered)

    @work(thread=True, group="cancel")
    def cancel(self, job):
        try:
            sjobs.run_scancel(job["job_id"], self.host)
        except click.ClickException as exc:
            message = exc.format_message()
            self.call_from_thread(self.notify, message, severity="error", markup=False)
            return
        self.call_from_thread(self.notify, f"Cancelled job {job['job_id']}.")
        self.call_from_thread(self.refresh_jobs)


def row_key(row):
    """A row's identity across redraws: its job, or its user."""
    if row.get("_group") is not None:
        return ("user", row["_group"])
    return row["job_id"]


def run_tui(**options):
    """Run the interactive watcher until the user quits."""
    # Without mouse capture the terminal's own selection works everywhere,
    # tables included, for copying IDs and paths.
    SjobsApp(terminal_colors=query_terminal_colors(), **options).run(mouse=False)
