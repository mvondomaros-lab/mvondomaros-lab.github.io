# sjobs

[![made-with-python](https://img.shields.io/badge/Made%20with-Python-green.svg)](https://www.python.org/)
[![MIT license](https://img.shields.io/badge/License-MIT-green.svg)](https://lbesson.mit-license.org/)

Show Slurm jobs grouped into running, pending, and other states, together with
your fair share and what drives each pending job's priority, either on a cluster
login node or from your own machine over SSH.

## Installation

See [https://mvondomaros-lab.github.io](https://mvondomaros-lab.github.io).

For a local development installation with Python 3.11 or newer:

```sh
python -m pip install -e .
```

## Usage

```sh
sjobs                 # Your jobs
sjobs --all           # All users' jobs
sjobs --user alice    # One user's jobs (takes precedence over --all)
sjobs -H mycluster    # Run squeue on an SSH host
sjobs -c cwd,nodes    # Extra columns: cwd, nodes, partition, priority, or all
sjobs --interval 120  # Refresh every 2 minutes (default 60 s, at least 30 s)
sjobs --version       # Show the installed version
python -m sjobs       # Also available as a Python module
```

The cluster must support `squeue --json` (sjobs was developed against Slurm 23.11).

## Configuration

sjobs runs `squeue` over SSH on the first host it finds, in this order:

1. `--host`/`-H HOST`
2. the `SJOBS_HOST` environment variable
3. `host` in the config file

Without a host it runs `squeue` locally, and fails with a hint if `squeue` is not
on `PATH`. The host is anything `ssh` accepts, so aliases from `~/.ssh/config`
work. On the remote side the Slurm tools run in a login shell (`sh -lc`), so `PATH`
set in your profile applies. The same call first prints the remote home directory
(both `$HOME` and its physical path, since Slurm records physical paths), so it is
shortened in paths without extra configuration. The default user filter
applies to the account running `squeue`, which is your remote account when using
SSH.

The config file is `$XDG_CONFIG_HOME/sjobs/config.toml` (default
`~/.config/sjobs/config.toml`). Set `SJOBS_CONFIG` to use another file.

```toml
host = "mycluster"
# Prefixes removed from paths, in addition to your home directory
# (local, or remote when using SSH).
path_prefixes = ["/scratch/", "/mnt/nfs/home/"]
# Optional columns to always show (same as --columns).
columns = ["cwd", "nodes"]
# Color theme of the interactive view. "auto" (the default) uses your
# terminal's own colors, light or dark; "ayu-light", "ayu-mirage",
# "ayu-dark" and any Textual theme name also work.
theme = "auto"
# How the three tables share the window: "auto" (stacked while they fit,
# else tabs), "stacked" or "tabs". `t` switches for the session.
layout = "auto"
# GPU model names to look for in job constraints, if sjobs does not
# recognize yours (a100, a40, l40s, h200, rtxpro6000 and similar are built in).
gpu_types = ["bigcard"]

# Opt-in, off by default: each adds load on shared Slurm services.
# Finished jobs of the last N hours (up to 720) from the accounting
# database: one sacct call at startup, and again after switching back from
# all users' jobs. Not used for all users' jobs.
history_hours = 24
# Free CPUs and idle nodes in the partitions your pending jobs wait for, in
# their details; from sinfo, run within each refresh's single command.
idle_nodes = true
```

Each refresh runs one shell script, locally or over a single SSH connection. It
calls `sshare` (your fair share), `sprio` (priority factors of pending jobs),
`sinfo` with `idle_nodes`, and exactly one `squeue` query, which includes all job states still known to the
controller. Only `squeue` is required: if `sshare` or `sprio` is missing or fails
(for example on clusters without the multifactor priority plugin), sjobs prints a
short note instead. A stuck connection or `squeue` is stopped after 60 seconds.

sjobs is an interactive view that repeats this every `--interval` seconds
(default 60, minimum 30); a failed refresh is shown and the last tables are
kept. It needs a terminal.

The footer lists the keys used most; `?` lists all of them.

| Key | Action |
|---|---|
| `↑` `↓`, `1` `2` `3` | move through the jobs (across tables), jump to running / pending / finished |
| `Enter` | show or hide the details of the selected row (a job, or a user's totals); `Esc` hides them too |
| `h` | check a running job: when its output file was last written, memory peak and CPU use (`sstat`) |
| `Space` | expand or fold an array job, or a user's jobs in the all-users view |
| `l` | the end of the selected job's output file (`e` switches to errors) |
| `y` | copy the selected job's ID |
| `/`, `Esc` | filter by job ID, name, user, path, partition or reason; clear (after closing the details) |
| `c` | cancel the selected job with `scancel`, after asking `y`/`n` |
| `a` | switch between your jobs and all users' jobs |
| `o` | choose optional columns |
| `t` | tables one above the other, or as tabs |
| `r` | refresh now |
| `?` | the keys, the marks and how to read the tables |
| `q` | quit |

What else the view does:

- **Needs you first.** Under the header, one line each for running jobs about
  to hit their time limit, pending jobs that will never start, and jobs that
  failed in the last hour.
- **Status marks** start each row: `●` running (yellow near its time limit),
  `○` pending, `!` held or waiting on something outside the queue, `✗` blocked
  for good or failed, `✓` completed.
- **Finished jobs stay.** Slurm forgets finished jobs after a few minutes; sjobs
  keeps those that end while it runs, until you quit.
- **Array jobs** fold into one row per array (`▸ sweep  3/10 done`), with the
  resources of one task times the number of tasks; `Space` shows the tasks, and
  all rows of one array stay together.
- **All users' jobs** (`--all`, `a`) come as one row per user with their totals,
  yours first and open; `Space` opens or folds the others.
- **Details pane.** `Enter` shows the selected row's details, following the
  cursor: beside the tables in windows at least 150 columns wide, below them in
  narrower ones, over them in windows under 20 rows. `Enter` or `Esc` hides it.
  The tables have the whole window until then.
- **Narrow windows** hide the least useful columns first (the ID, then limits
  and waits) instead of cutting off the reasons; the section line says how many
  are hidden. Columns that are empty for every row are left out.
- **Tabs** replace the stacked tables when they do not fit the window; once
  switched, they switch back only when the tables fit again, so a few new jobs
  do not flip the layout back and forth.
- **Changes are announced**: when a job starts or ends between refreshes, a
  notification names it (failures in red) and its row stands out for a few
  seconds. With `desktop_notifications = true` in the config, sjobs also
  asks the terminal for a desktop notification (OSC 9: iTerm2, Ghostty, WezTerm,
  kitty and others).

Reading a log (`l`), checking a job (`h`) and cancelling (`c`) each run one
extra command (`tail`, `stat` and `sstat`, or `scancel`) when you ask for them.
`sstat` asks the compute nodes, not the Slurm controller.

The view takes its colors from your terminal: at startup it asks the terminal for
its background, text color and 16-color palette and builds a theme from them, so
it matches any light or dark terminal theme. Faint text is a gray mixed from
your text and background colors, which stays readable on light themes. Text is
never yellow or cyan, which are hard to read on light backgrounds; those colors
only mark status signs and bars. Terminals that do not answer get Textual's light
or dark theme. `Ctrl+P` offers other themes for the session (Ayu Light, Mirage
and Dark among them), and `theme = "…"` in the config picks one permanently.

sjobs leaves the mouse to your terminal, so you select and copy text (job IDs,
paths, log lines) as in any other program; everything is done with keys. `y`
copies the selected job's ID through the terminal's clipboard support (OSC 52),
which also works over SSH; some terminals need it enabled (in iTerm2: Settings ›
General › Selection › Applications in terminal may access clipboard).

Avoid leaving it on all users' jobs (`--all` or `a`) for long, as that adds load
on the Slurm controller.

### Faster SSH

Most of a remote run is spent setting up the SSH connection. Reusing one
connection makes every refresh nearly instant and
avoids repeated logins on the cluster's login node:

```sshconfig
Host mycluster
    ControlMaster auto
    ControlPath ~/.ssh/cm-%C
    ControlPersist 10m
```

For older completed jobs, set `history_hours` or use `sacct`. See the
[squeue manual](https://slurm.schedmd.com/squeue.html) for details.

## Output

A text rendering of the view, 120 columns wide:

```
mycluster · my jobs   using 92 CPUs · 192G · 1 GPU · fair share low       updated 16:19 · next in 0:59
● eq-npt 5002 reaches its time limit today 16:29 (9m left)
✗ relax-big 5021 time limit exceeds the partition's maximum
✗ 3 jobs failed in the last hour: md-long, analysis, plot

── Running · 5 ──────────────────────────────────────────────────────────────────────────────────────────
   Name               Resources           Time left           Ends          ID
●  eq-npt             64c 128G            ━━━━━━━━━━ 9m       today 16:29   5002
●  md run  run01      16c 16G A100·80GB   ━━━━━━━━━─ 1h39m    today 17:59   5001
●  ▸ scan  0/10 done  4c 16G ×3           ━━━─────── 3h59m    today 20:19   5010_[0-2]

── Pending · 6 ──────────────────────────────────────────────────────────────────────────────────────────
   Name               Resources          Limit   Waited   Why                                        ID
○  queued             8c 32G A100|A40   12h00m   16h00m   in line                                    5022
○  md run  run02      16c 16G A100      12h00m    5h00m   next, waiting for free nodes               5024
!  debug              1c 2G                30m    3h00m   held by you                                5023
○  scan  0/10 done    4c 16G             6h00m    2h00m   array task limit (%) reached               5010_[3-9]
○  analysis  run01    2c 8G              2h00m    2h00m   after md run succeeds (ends today 17:59)   5020
✗  relax-big          128c 256G          9d00h    2h00m   time limit exceeds the partition's maximum 5021

── Finished · 4 ─────────────────────────────────────────────────────────────────────────────────────────
   Name               Outcome            Ran   Ended         Note               ID
✗  plot               failed (exit 1)     1m   today 16:10   l shows the log    4993
✗  analysis  run00    out of memory       3m   today 16:02   requested 4G       4992
✗  md-long            timed out       12h00m   today 15:49   limit was 12h00m   4991
✓  prep               completed        2h10m   today 15:29                      4990
```

What the view shows:

- **Header.** The host, whose jobs, the CPUs, memory and GPUs your running jobs
  hold, when the data was fetched and when the next refresh comes.
- **Running.** A bar of the time limit used, with the time left (yellow from
  90%, because Slurm stops the job at its limit), and the clock time it ends.
- **Pending.** The requested time limit, how long the job has waited, Slurm's
  estimated start (`~today 21:00`, only when it has one), and **Why** it waits,
  in words. Routine reasons are faint (`in line`: jobs with a higher priority go
  first; `next`: it has the highest priority and waits for nodes); red ones need
  you. Jobs waiting on another job name it, with its state or end time. With
  `idle_nodes`, the details of a job waiting its turn say how many CPUs are free
  and nodes idle in the partitions it waits for (not for held jobs or ones
  waiting on other jobs). The top line always shows your fair share in words
  (good from 0.5, fair from 0.2, low below); a pending job's details say what it
  means for that job.
- **Finished.** How each job ended, exit code included, how long it ran, when it
  ended, and a note on why it failed (`limit was 12h00m`, `requested 4G`). Its
  details say what to change. With `history_hours`, it also lists the jobs that
  finished in that many hours before sjobs started.
- **Names** that repeat show the end of their directory (`md run  run01`), so
  ten jobs called `run.sh` can be told apart.
- **Details** (`Enter`) start with what matters for the job's state:
  when a running job ends, why a pending one waits and what to do, why a
  finished one ended as it did. Then resources, files and the job's identity.
- **Optional columns** (`--columns`, `columns` in the config, `o` in the
  interactive view): `cwd` (working directory), `nodes`, `partition`, and
  `priority` (the priority of pending jobs with its weighted factors, e.g.
  `17331 (partition 96%, fair share 2%, waiting time 1%)`).

Running jobs are sorted by end time, pending jobs by priority (then submission),
and finished jobs most recent first. Long job IDs, names, reasons and paths are
cut to a maximum width. Paths have your home directory and any `path_prefixes`
removed.

Array tasks keep identifiers such as `1000_4` or `1000_[1-4]`, heterogeneous jobs
show the component as `1000+0`. Resources are compact: `16c 16G A100·80GB` is 16
CPUs, 16 GB of memory and one A100 with 80 GB. GPUs show the allocated models
once a job runs, else the request with its scope (`2×GPU/node`). A job that asks
for an untyped `--gpus 1` and picks the model with `--constraint "a100|a40"`
shows `A100|A40`; a plain `GPU` means any model. Clock times are relative to
today (`today 18:05`, `Thu 09:12`) in your computer's timezone.

## Development

```sh
pixi run test     # unit tests
pixi run lint     # ruff check and format check
pixi run format   # apply ruff fixes and formatting
```

Or, after installing the package:

```sh
python -m unittest discover -s tests -v
```

Tests use synthetic fixtures modeled on Slurm's `squeue --json`, `sshare -P` and
`sprio -o` output, with
mocked subprocesses and an isolated config. They do not contact a cluster or
submit jobs. Pull requests run ruff and the tests on Python 3.11 and 3.14, and the
build/deploy workflow requires them to pass before building artifacts.

Pushes to `main` and `dev` build artifacts as a dry run. To release, set
`version` in `pyproject.toml`, merge into `main`, and push a matching tag
(`git tag v0.8 && git push origin v0.8`). The tag build publishes the conda
package and wheel to the lab's pages repository via a pull request there.

